import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Lock, Mail, Loader2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { getOrgSettings, applySystemName } from '../utils/orgSettings';
import { API_BASE_URL } from '../config';

export default function Login() {
  const [systemName, setSystemName] = useState('Agricultural Promotion Bank CO.,LTD');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  // path ທີ່ຜູ້ໃຊ້ຖືກສົ່ງມາ login (ເຊັ່ນສະແກນ QR ເຂົ້າ /assets/:id) — ຖ້າບໍ່ມີກັບໄປໜ້າຫຼັກ
  const from = location.state?.from;
  const redirectTo = from ? `${from.pathname || '/'}${from.search || ''}${from.hash || ''}` : '/';

  // MFA challenge step (shown after login returns mfaRequired)
  const [mfaStep, setMfaStep] = useState(false);
  const [mfaToken, setMfaToken] = useState('');
  const [mfaMethod, setMfaMethod] = useState('');
  const [mfaCode, setMfaCode] = useState('');
  const [mfaSubmitting, setMfaSubmitting] = useState(false);
  const [resending, setResending] = useState(false);

  const [setupToken, setSetupToken] = useState('');
  const [mfaSetupStep, setMfaSetupStep] = useState(null); // null | 'choose' | 'totp' | 'email'
  const [setupQr, setSetupQr] = useState('');
  const [setupCode, setSetupCode] = useState('');
  const [setupSubmitting, setSetupSubmitting] = useState(false);
  const [resendingSetup, setResendingSetup] = useState(false);

  // Forgot password flow: null | 'email' | 'reset' | 'done'
  const [forgotStep, setForgotStep] = useState(null);
  const [resetCode, setResetCode] = useState('');
  const [resetMfaCode, setResetMfaCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forgotSubmitting, setForgotSubmitting] = useState(false);
  const [forgotInfo, setForgotInfo] = useState('');

  // ດຶງຊື່ລະບົບຈາກການຕັ້ງຄ່າອົງກອນ ມາສະແດງໃນໜ້າ Login
  useEffect(() => {
    let cancelled = false;
    getOrgSettings().then((settings) => {
      if (cancelled) return;
      setSystemName(settings.systemName);
      applySystemName(settings.systemName);
    });
    return () => { cancelled = true; };
  }, []);

  const handleChooseSetupMethod = async (method) => {
    setError('');
    setSetupSubmitting(true);
    try {
      const response = await fetch(`${API_BASE_URL}/auth/mfa/setup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${setupToken}`,
        },
        body: JSON.stringify({ method }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.msg || 'ຕັ້ງຄ່າ MFA ບໍ່ສຳເລັດ');

      if (method === 'totp') {
        setSetupQr(result.data.qrCodeDataUrl);
        setMfaSetupStep('totp');
      } else {
        setMfaSetupStep('email');
      }
    } catch (err) {
      setError(err.message || 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ Server');
    } finally {
      setSetupSubmitting(false);
    }
  };

  const handleEnableMfa = async (e) => {
    e.preventDefault();
    setError('');
    setSetupSubmitting(true);
    try {
      const response = await fetch(`${API_BASE_URL}/auth/mfa/enable`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${setupToken}`,
        },
        body: JSON.stringify({ code: setupCode }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.msg || 'ລະຫັດບໍ່ຖືກຕ້ອງ');

      completeLoginWithToken(result.data.accessToken);
    } catch (err) {
      setError(err.message || 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ Server');
    } finally {
      setSetupSubmitting(false);
    }
  };

  const handleResendSetupCode = async () => {
    setResendingSetup(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE_URL}/auth/mfa/resend-code`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${setupToken}` },
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.msg || 'ສົ່ງລະຫັດຄືນບໍ່ສຳເລັດ');
    } catch (err) {
      setError(err.message || 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ Server');
    } finally {
      setResendingSetup(false);
    }
  };

  const openForgot = () => {
    setError('');
    setForgotInfo('');
    setResetCode('');
    setResetMfaCode('');
    setNewPassword('');
    setConfirmPassword('');
    setForgotStep('email');
  };

  const closeForgot = () => {
    setError('');
    setForgotInfo('');
    setForgotStep(null);
  };

  const handleSendResetCode = async (e) => {
    if (e) e.preventDefault();
    setError('');
    setForgotInfo('');
    setForgotSubmitting(true);
    try {
      const response = await fetch(`${API_BASE_URL}/auth/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.msg || 'ສົ່ງລະຫັດບໍ່ສຳເລັດ');
      setForgotInfo('ຖ້າອີເມວນີ້ມີໃນລະບົບ ພວກເຮົາໄດ້ສົ່ງລະຫັດ 6 ຫຼັກໄປທີ່ອີເມວແລ້ວ (ໝົດອາຍຸໃນ 10 ນາທີ)');
      setForgotStep('reset');
    } catch (err) {
      setError(err.message || 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ Server');
    } finally {
      setForgotSubmitting(false);
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    setError('');
    if (newPassword.length < 8) {
      setError('ລະຫັດຜ່ານຕ້ອງມີຢ່າງໜ້ອຍ 8 ຕົວອັກສອນ');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('ລະຫັດຜ່ານໃໝ່ທັງສອງຊ່ອງບໍ່ຕົງກັນ');
      return;
    }
    setForgotSubmitting(true);
    try {
      const response = await fetch(`${API_BASE_URL}/auth/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          code: resetCode,
          newPassword,
          ...(resetMfaCode ? { mfaCode: resetMfaCode } : {}),
        }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.msg || 'ລະຫັດບໍ່ຖືກຕ້ອງ ຫຼື ໝົດອາຍຸ');
      setPassword('');
      setForgotInfo('');
      setForgotStep('done');
    } catch (err) {
      setError(err.message || 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ Server');
    } finally {
      setForgotSubmitting(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.msg || 'ອີເມວ ຫຼື ລະຫັດຜ່ານບໍ່ຖືກຕ້ອງ');
      }

      if (result.data.mfaSetupRequired) {
        setSetupToken(result.data.setupToken);
        setMfaSetupStep('choose');
        setLoading(false);
        return;
      }

      if (result.data.mfaRequired) {
        setMfaToken(result.data.mfaToken);
        setMfaMethod(result.data.mfaMethod);
        setMfaStep(true);
        setLoading(false);
        return;
      }

      completeLoginWithToken(result.data.accessToken);
    } catch (err) {
      setError(err.message || 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ Server');
    } finally {
      setLoading(false);
    }
  };

  // Shared by normal login and MFA-verified login — both end up with an accessToken.
  const completeLoginWithToken = (token) => {
    localStorage.setItem('token', token);

    // Backend doesn't return a separate user object — decode the JWT
    // payload (just base64, not encrypted) to get email/role/permissions
    // for the sidebar/navbar to use.
    const payload = JSON.parse(atob(token.split('.')[1]));
    localStorage.setItem('user', JSON.stringify({
      email: payload.email,
      role: payload.role,
      permissions: payload.permissions,
    }));

    navigate(redirectTo);
    window.location.reload();
  };

  const handleMfaVerify = async (e) => {
    e.preventDefault();
    setError('');
    setMfaSubmitting(true);
    try {
      const response = await fetch(`${API_BASE_URL}/auth/mfa/verify-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mfaToken, code: mfaCode }),
      });
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.msg || 'ລະຫັດບໍ່ຖືກຕ້ອງ');
      }
      completeLoginWithToken(result.data.accessToken);
    } catch (err) {
      setError(err.message || 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ Server');
    } finally {
      setMfaSubmitting(false);
    }
  };

  const handleResendCode = async () => {
    setResending(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE_URL}/auth/mfa/login/resend-code`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mfaToken }),
      });
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.msg || 'ສົ່ງລະຫັດຄືນບໍ່ສຳເລັດ');
      }
    } catch (err) {
      setError(err.message || 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ Server');
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-emerald-950 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute -top-20 -left-20 w-72 h-72 bg-yellow-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-20 -right-20 w-72 h-72 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="bg-emerald-900/50 border border-yellow-500/30 backdrop-blur-xl rounded-2xl w-full max-w-md p-8 shadow-2xl space-y-6 relative z-10">

        <div className="text-center space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-yellow-500 via-amber-400 to-yellow-600 text-emerald-950 font-black flex items-center justify-center text-xl mx-auto shadow-lg shadow-yellow-500/20 border-2 border-yellow-300">
            APB
          </div>
          <div>
            <h1 translate="no" className="text-lg font-bold text-white tracking-wide">ທະນາຄານສົ່ງເສີມກະສິກຳ ຈຳກົດ</h1>
            <p translate="no" className="text-base text-yellow-400 font-medium mt-0.5">Agricultural Promotion Bank Co., Ltd</p>
          </div>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-xl text-sm flex items-center gap-2">
            <AlertCircle size={18} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {forgotStep ? (
          <div className="space-y-4">
            {forgotStep === 'email' && (
              <form onSubmit={handleSendResetCode} className="space-y-4">
                <p className="text-sm text-yellow-200/90">ປ້ອນອີເມວຂອງບັນຊີ — ພວກເຮົາຈະສົ່ງລະຫັດຢືນຢັນ 6 ຫຼັກໄປໃຫ້</p>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 text-yellow-400" size={18} />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jano@example.com"
                    className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 pl-10 text-sm text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                  />
                </div>
                <button type="submit" disabled={forgotSubmitting || !email} className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-emerald-950 font-bold py-3 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20 disabled:opacity-50">
                  {forgotSubmitting ? <Loader2 className="animate-spin" size={18} /> : <span>ສົ່ງລະຫັດ</span>}
                </button>
                <button type="button" onClick={closeForgot} className="w-full text-yellow-300 text-xs underline">
                  ກັບໄປໜ້າເຂົ້າສູ່ລະບົບ
                </button>
              </form>
            )}

            {forgotStep === 'reset' && (
              <form onSubmit={handleResetPassword} className="space-y-4">
                {forgotInfo && <p className="text-sm text-yellow-200/90">{forgotInfo}</p>}
                <div>
                  <label className="block text-xs font-medium text-yellow-200/90 mb-1">ລະຫັດຈາກອີເມວ</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={resetCode}
                    onChange={(e) => setResetCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="123456"
                    className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 text-center tracking-[0.5em] text-lg text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-yellow-200/90 mb-1">
                    ລະຫັດຈາກແອັບ Authenticator (ຖ້າບັນຊີເປີດໃຊ້ MFA ແບບ Authenticator)
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={resetMfaCode}
                    onChange={(e) => setResetMfaCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="ບໍ່ບັງຄັບ"
                    className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 text-center tracking-[0.5em] text-lg text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-yellow-200/90 mb-1">ລະຫັດຜ່ານໃໝ່</label>
                  <input
                    type="password"
                    required
                    minLength={8}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="ຢ່າງໜ້ອຍ 8 ຕົວອັກສອນ"
                    className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 text-sm text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-yellow-200/90 mb-1">ຢືນຢັນລະຫັດຜ່ານໃໝ່</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 text-sm text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                  />
                </div>
                <button
                  type="submit"
                  disabled={forgotSubmitting || resetCode.length !== 6 || !newPassword}
                  className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-emerald-950 font-bold py-3 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20 disabled:opacity-50"
                >
                  {forgotSubmitting ? <Loader2 className="animate-spin" size={18} /> : <span>ປ່ຽນລະຫັດຜ່ານ</span>}
                </button>
                <button
                  type="button"
                  onClick={handleSendResetCode}
                  disabled={forgotSubmitting}
                  className="w-full text-yellow-300 text-xs underline disabled:opacity-50"
                >
                  ສົ່ງລະຫັດອີກຄັ້ງ
                </button>
                <button type="button" onClick={closeForgot} className="w-full text-yellow-300 text-xs underline">
                  ຍົກເລີກ
                </button>
              </form>
            )}

            {forgotStep === 'done' && (
              <div className="space-y-4 text-center">
                <CheckCircle2 className="mx-auto text-emerald-400" size={40} />
                <p className="text-sm text-yellow-200/90">ປ່ຽນລະຫັດຜ່ານສຳເລັດແລ້ວ — ກະລຸນາເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານໃໝ່</p>
                <button type="button" onClick={closeForgot} className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-emerald-950 font-bold py-3 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20 disabled:opacity-50">
                  ເຂົ້າສູ່ລະບົບ
                </button>
              </div>
            )}
          </div>
        ) : mfaSetupStep ? (
          <div className="space-y-4">
            {mfaSetupStep === 'choose' && (
              <>
                <p className="text-sm text-yellow-200/90">ບັນຊີນີ້ຕ້ອງການຕັ້ງຄ່າ MFA ກ່ອນເຂົ້າສູ່ລະບົບ — ເລືອກວິທີ:</p>
                <button
                  type="button"
                  disabled={setupSubmitting}
                  onClick={() => handleChooseSetupMethod('totp')}
                  className="w-full bg-emerald-950/80 border border-emerald-600/60 hover:border-yellow-400 text-white py-3 rounded-xl text-sm transition disabled:opacity-50"
                >
                  ແອັບ Authenticator (Google Authenticator, Authy...)
                </button>
                <button
                  type="button"
                  disabled={setupSubmitting}
                  onClick={() => handleChooseSetupMethod('email')}
                  className="w-full bg-emerald-950/80 border border-emerald-600/60 hover:border-yellow-400 text-white py-3 rounded-xl text-sm transition disabled:opacity-50"
                >
                  ອີເມວ
                </button>
              </>
            )}

            {mfaSetupStep === 'totp' && (
              <form onSubmit={handleEnableMfa} className="space-y-4">
                <p className="text-sm text-yellow-200/90">ສະແກນ QR ນີ້ດ້ວຍແອັບ Authenticator ຂອງທ່ານ:</p>
                {setupQr && (
                  <img src={setupQr} alt="MFA QR code" className="mx-auto rounded-xl bg-white p-2" style={{ width: 200, height: 200 }} />
                )}
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={setupCode}
                  onChange={(e) => setSetupCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="123456"
                  className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 text-center tracking-[0.5em] text-lg text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                />
                <button
                  type="submit"
                  disabled={setupSubmitting || setupCode.length !== 6}
                  className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-emerald-950 font-bold py-3 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20 disabled:opacity-50"
                >
                  {setupSubmitting ? <Loader2 className="animate-spin" size={18} /> : <span>ຢືນຢັນ ແລະ ເປີດໃຊ້ MFA</span>}
                </button>
              </form>
            )}

            {mfaSetupStep === 'email' && (
              <form onSubmit={handleEnableMfa} className="space-y-4">
                <p className="text-sm text-yellow-200/90">ພວກເຮົາໄດ້ສົ່ງລະຫັດໄປທາງອີເມວຂອງທ່ານແລ້ວ</p>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={setupCode}
                  onChange={(e) => setSetupCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="123456"
                  className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 text-center tracking-[0.5em] text-lg text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                />
                <button
                  type="submit"
                  disabled={setupSubmitting || setupCode.length !== 6}
                  className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-emerald-950 font-bold py-3 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20 disabled:opacity-50"
                >
                  {setupSubmitting ? <Loader2 className="animate-spin" size={18} /> : <span>ຢືນຢັນ ແລະ ເປີດໃຊ້ MFA</span>}
                </button>
                <button
                  type="button"
                  onClick={handleResendSetupCode}
                  disabled={resendingSetup}
                  className="w-full text-yellow-300 text-xs underline disabled:opacity-50"
                >
                  {resendingSetup ? 'ກຳລັງສົ່ງ...' : 'ສົ່ງລະຫັດອີກຄັ້ງ'}
                </button>
              </form>
            )}
          </div>
        ) : !mfaStep ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-yellow-200/90 mb-1">ອີເມວ (Email)</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 text-yellow-400" size={18} />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="jano@example.com"
                  className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 pl-10 text-sm text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-yellow-200/90 mb-1">ລະຫັດຜ່ານ (Password)</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 text-yellow-400" size={18} />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 pl-10 text-sm text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
                />
              </div>
            </div>

            <div className="text-right -mt-1">
              <button type="button" onClick={openForgot} className="text-yellow-300 text-xs underline">
                ລືມລະຫັດຜ່ານ? (Forgot password)
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-emerald-950 font-bold py-3 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20 disabled:opacity-50 mt-2"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : <span>ເຂົ້າສູ່ລະບົບ</span>}
            </button>
          </form>

        ) : (
          <form onSubmit={handleMfaVerify} className="space-y-4">
            <p className="text-sm text-yellow-200/90">
              {mfaMethod === 'email'
                ? 'ພວກເຮົາໄດ້ສົ່ງລະຫັດໄປທາງອີເມວຂອງທ່ານແລ້ວ'
                : 'ປ້ອນລະຫັດຈາກແອັບ Authenticator ຂອງທ່ານ'}
            </p>
            <input
              type="text"
              required
              maxLength={6}
              value={mfaCode}
              onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, ''))}
              placeholder="123456"
              className="w-full bg-emerald-950/80 border border-emerald-600/60 rounded-xl px-4 py-2.5 text-center tracking-[0.5em] text-lg text-white placeholder-emerald-400/50 focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition"
            />
            <button
              type="submit"
              disabled={mfaSubmitting || mfaCode.length !== 6}
              className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-emerald-950 font-bold py-3 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20 disabled:opacity-50"
            >
              {mfaSubmitting ? <Loader2 className="animate-spin" size={18} /> : <span>ຢືນຢັນ</span>}
            </button>
            {mfaMethod === 'email' && (
              <button
                type="button"
                onClick={handleResendCode}
                disabled={resending}
                className="w-full text-yellow-300 text-xs underline disabled:opacity-50"
              >
                {resending ? 'ກຳລັງສົ່ງ...' : 'ສົ່ງລະຫັດອີກຄັ້ງ'}
              </button>
            )}
          </form>
        )}

      </div>
    </div>
  );
}