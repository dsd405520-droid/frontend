import { Fragment, useEffect, useRef, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Plus, X, AlertCircle, Search, UserCheck, Undo2,
  Wrench, History, AlertTriangle, Trash2, Barcode, Archive, Camera,
  CheckCircle2, XCircle, Folder, FolderOpen, ChevronDown, ChevronRight, ChevronsDown, ChevronsUp, ExternalLink, FileText, FileSpreadsheet,
} from 'lucide-react';
import { hasPermission, getCurrentUser } from '../utils/permissions';
import MainLayout from '../layouts/MainLayout';
import CsvImportButton from '../components/CsvImportButton';
import CsvExportButton from '../components/CsvExportButton';
import CameraScanner from '../components/CameraScanner';
import AssetTagVisual from '../components/AssetTagVisual';
import AssetTimeline from '../components/AssetTimeline';
import { CatalogThumb } from '../components/CatalogImage';
import AssetTagPrintModal from '../components/AssetTagPrintModal';
import { API_BASE_URL } from '../config';
import useRealtimeRefresh from '../hooks/useRealtimeRefresh';
import { buildAssetExport, downloadAssetCsv, printAssetPdf } from '../utils/assetExport';

function DetailField({ label, children, wide }) {
  return (
    <div className={wide ? 'sm:col-span-2' : ''}>
      <div className="text-xs text-gray-400">{label}</div>
      <div className="text-sm font-medium text-gray-800 break-words">{children}</div>
    </div>
  );
}

const DETAIL_TONE = {
  gray: 'border-gray-200 text-gray-700 hover:bg-gray-50',
  blue: 'border-blue-200 text-blue-600 hover:bg-blue-50',
  green: 'border-emerald-200 text-emerald-600 hover:bg-emerald-50',
  amber: 'border-amber-200 text-amber-700 hover:bg-amber-50',
  red: 'border-red-200 text-red-600 hover:bg-red-50',
};

function DetailBtn({ onClick, Icon, label, tone, disabled }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={label}
      className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-medium whitespace-nowrap bg-white disabled:opacity-40 ${DETAIL_TONE[tone]}`}
    >
      <Icon size={14} />
      {label}
    </button>
  );
}

export default function AssetRegistry() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = localStorage.getItem('token') || '';
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  const publicBaseUrl = (import.meta.env.VITE_PUBLIC_BASE_URL || '').replace(/\/+$/, '');
  const claimBaseUrl = publicBaseUrl || window.location.origin;
  const isLocalOrigin = !publicBaseUrl && ['localhost', '127.0.0.1'].includes(window.location.hostname);
  const isIpOrigin = !publicBaseUrl && /^\d{1,3}(\.\d{1,3}){3}$/.test(window.location.hostname);

  const canCreate = hasPermission('assets', 'create');
  const canRead = hasPermission('assets', 'read');
  const canUpdate = hasPermission('assets', 'update');
  const canDelete = hasPermission('assets', 'delete');
  const canAssign = hasPermission('assets', 'assign');
  const canSelect = canRead || canAssign || canUpdate || canDelete;

  const [activeTab, setActiveTab] = useState('registry');

  const [assets, setAssets] = useState([]);
  const [loadingAssets, setLoadingAssets] = useState(true);
  const [assetsError, setAssetsError] = useState('');

  const [branches, setBranches] = useState([]);
  const [catalog, setCatalog] = useState([]);
  const assetCatalog = catalog.filter((item) => item.itemType === 'ASSET');
  const [users, setUsers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [selectedDeptId, setSelectedDeptId] = useState("");

  const [overdue, setOverdue] = useState([]);
  const [loadingOverdue, setLoadingOverdue] = useState(false);
  const [overdueError, setOverdueError] = useState('');

  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [statusFilter, setStatusFilter] = useState('');
  const [branchFilter, setBranchFilter] = useState('');

  const MAX_BATCH = 50;
  const parseTags = (s) => [...new Set(String(s || '').split(/[\s,;]+/).map((t) => t.trim()).filter(Boolean))];
  const rowSeq = useRef(0);
  const newRow = (over = {}) => ({
    id: ++rowSeq.current, catalogSearch: '', catalogItemId: '', name: '', qty: 1,
    assetTag: '', purchaseDate: '', warrantyExpiry: '', showDates: false, ...over,
  });
  const fromRequestId = searchParams.get('fromRequest') || '';
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [batchRows, setBatchRows] = useState([]);
  const [batchBranch, setBatchBranch] = useState('');
  const [batchPurchase, setBatchPurchase] = useState('');
  const [batchWarranty, setBatchWarranty] = useState('');
  const [batchDone, setBatchDone] = useState({});
  const [batchResult, setBatchResult] = useState(null);
  const [batchError, setBatchError] = useState('');
  const [batchSubmitting, setBatchSubmitting] = useState(false);
  const [batchFinished, setBatchFinished] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerSearch, setPickerSearch] = useState('');
  const [pickerSelected, setPickerSelected] = useState(() => new Set());
  const [reqData, setReqData] = useState(null);
  const [reqError, setReqError] = useState('');
  const prefilledFor = useRef('');

  const [assignModalAsset, setAssignModalAsset] = useState(null);
  const [assignUserId, setAssignUserId] = useState('');
  const [assignNote, setAssignNote] = useState('');
  const [assignMode, setAssignMode] = useState('PERSON');
  const [custodianId, setCustodianId] = useState('');
  const [proxyOn, setProxyOn] = useState(false);
  const [proxyCode, setProxyCode] = useState('');
  const [proxyLookup, setProxyLookup] = useState(null);
  const [holderTypeFilter, setHolderTypeFilter] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [assignSubmitting, setAssignSubmitting] = useState(false);
  const [assignError, setAssignError] = useState('');

  const [barcodeModalAsset, setBarcodeModalAsset] = useState(null);
  const [historyModalAsset, setHistoryModalAsset] = useState(null);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scanTargetId, setScanTargetId] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [expandedFolders, setExpandedFolders] = useState(() => new Set());
  const [detailAssetId, setDetailAssetId] = useState(null);
  const [exportingAssetId, setExportingAssetId] = useState(null);
  const [receipts, setReceipts] = useState(null);
  const [collapsedSubs, setCollapsedSubs] = useState(() => new Set());

  const [selectedIds, setSelectedIds] = useState(() => new Set());
  const [bulkOpBusy, setBulkOpBusy] = useState(false);
  const [bulkPrintOpen, setBulkPrintOpen] = useState(false);
  const [bulkAssignOpen, setBulkAssignOpen] = useState(false);
  const [bulkAssignUserId, setBulkAssignUserId] = useState('');
  const [bulkAssignNote, setBulkAssignNote] = useState('');
  const [bulkUserSearch, setBulkUserSearch] = useState('');
  const [bulkUserDept, setBulkUserDept] = useState('');
  const [bulkAssignError, setBulkAssignError] = useState('');
  const [bulkClaimOpen, setBulkClaimOpen] = useState(false);
  const [bulkClaimSubmitting, setBulkClaimSubmitting] = useState(false);
  const [bulkClaimError, setBulkClaimError] = useState('');
  const [bulkClaimResults, setBulkClaimResults] = useState(null);
  const [bulkClaimCode, setBulkClaimCode] = useState('');
  const [bulkClaimDept, setBulkClaimDept] = useState('');
  const [bulkLookup, setBulkLookup] = useState({ state: 'idle', user: null });

  const currentUser = getCurrentUser();
  const claimUser = users.find(
    (u) => (currentUser?._id && u._id === currentUser._id) || (currentUser?.email && u.email === currentUser.email),
  ) || currentUser;

  function unwrap(body) {
    return body?.data !== undefined ? body.data : body;
  }

  function fetchAssets(opts) {
    const silent = opts?.silent === true;
    if (!silent) {
      setLoadingAssets(true);
      setAssetsError('');
    }
    const branchParam = branchFilter ? `?branchId=${encodeURIComponent(branchFilter)}` : '';
    return fetch(`${API_BASE_URL}/assets${branchParam}`, { headers })
      .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) throw new Error(body?.msg || 'ບໍ່ສາມາດໂຫຼດທະບຽນຊັບສິນໄດ້');
        setAssets(unwrap(body) || []);
        setAssetsError('');
      })
      .catch((err) => {
        if (!silent) setAssetsError(err.message);
      })
      .finally(() => {
        if (!silent) setLoadingAssets(false);
      });
  }

  function fetchBranches() {
    fetch(`${API_BASE_URL}/branches`, { headers })
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then((body) => setBranches(unwrap(body) || []))
      .catch(() => setBranches([]));
  }

  function fetchUsers() {
    fetch(`${API_BASE_URL}/users`, { headers })
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then((body) => setUsers(unwrap(body) || []))
      .catch(() => setUsers([]));
  }

  function fetchDepartments() {
    fetch(`${API_BASE_URL}/departments`, { headers })
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then((body) => setDepartments(unwrap(body) || []))
      .catch(() => setDepartments([]));
  }

  function fetchCatalog(opts) {
    const silent = opts?.silent === true;
    return fetch(`${API_BASE_URL}/supply-catalog`, { headers })
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then((body) => setCatalog(unwrap(body) || []))
      .catch(() => {
        if (!silent) setCatalog([]);
      });
  }

  function fetchReceipts(opts) {
    const silent = opts?.silent === true;
    return fetch(`${API_BASE_URL}/goods-receipt`, { headers })
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then((body) => setReceipts(Array.isArray(unwrap(body)) ? unwrap(body) : null))
      .catch(() => {
        if (!silent) setReceipts(null);
      });
  }

  const resetBatch = () => {
    setBatchRows([newRow()]);
    setBatchBranch('');
    setBatchPurchase('');
    setBatchWarranty('');
    setBatchDone({});
    setBatchResult(null);
    setBatchError('');
    setBatchFinished(false);
    setPickerOpen(false);
    setPickerSearch('');
    setPickerSelected(new Set());
  };

  const openCreate = () => {
    resetBatch();
    setShowCreateModal(true);
  };

  function fetchOverdue(opts) {
    const silent = opts?.silent === true;
    if (!silent) {
      setLoadingOverdue(true);
      setOverdueError('');
    }
    return fetch(`${API_BASE_URL}/assets/overdue`, { headers })
      .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) throw new Error(body?.msg || 'ບໍ່ສາມາດໂຫຼດລາຍງານໄດ້');
        setOverdue(unwrap(body) || []);
        setOverdueError('');
      })
      .catch((err) => {
        if (!silent) setOverdueError(err.message);
      })
      .finally(() => {
        if (!silent) setLoadingOverdue(false);
      });
  }

  useRealtimeRefresh(() =>
    Promise.all([
      fetchAssets({ silent: true }),
      fetchReceipts({ silent: true }),
      canCreate ? fetchCatalog({ silent: true }) : null,
      activeTab === 'overdue' ? fetchOverdue({ silent: true }) : null,
    ]),
  );

  useEffect(() => {
    fetchAssets();
    fetchBranches();
    fetchUsers();
    fetchDepartments();
    fetchReceipts();
    if (canCreate) fetchCatalog();
  }, [branchFilter]);

  useEffect(() => {
    if (searchParams.get('create') === '1') {
      openCreate();
    }
  }, [searchParams.get('create')]);

  useEffect(() => {
    if (!fromRequestId || !canCreate) return;
    prefilledFor.current = '';
    setReqData(null);
    setReqError('');
    openCreate();
    fetch(`${API_BASE_URL}/supply-requests/${encodeURIComponent(fromRequestId)}/receipt`, { headers })
      .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) throw new Error(body?.msg || 'ບໍ່ສາມາດໂຫຼດໃບຂໍໄດ້');
        setReqData(unwrap(body));
      })
      .catch((err) => setReqError(err.message));
  }, [fromRequestId]);

  useEffect(() => {
    if (!fromRequestId || !reqData || loadingAssets || catalog.length === 0 || prefilledFor.current === fromRequestId) return;
    prefilledFor.current = fromRequestId;
    const rows = [];
    (reqData.items || []).forEach((it) => {
      const nm = (it.name || '').toLowerCase();
      const catalogMatch = catalog.find((c) => (it.catalogItemId && c._id === it.catalogItemId) || (nm && (c.name || '').toLowerCase() === nm));
      if (catalogMatch && catalogMatch.itemType !== 'ASSET') return;
      if (it.catalogItemId && !catalogMatch) return;
      const cat = catalogMatch;
      const targetBranchId = reqData.departmentId && typeof reqData.departmentId === 'object'
        ? reqData.departmentId.branchId
        : '';
      const available = assets.filter((a) => {
        if (a.status !== 'AVAILABLE') return false;
        const assetBranchId = a.branchId && typeof a.branchId === 'object' ? a.branchId._id : a.branchId;
        if (targetBranchId && assetBranchId !== targetBranchId) return false;
        const t = (a.type || '').toLowerCase();
        return (cat && a.catalogItemId === cat._id) || (nm && t && (nm.includes(t) || t.includes(nm)));
      }).length;
      const missing = Math.max(0, (Number(it.quantity) || 0) - available);
      if (missing > 0) rows.push(newRow({ catalogSearch: cat?.name || it.name || '', catalogItemId: cat?._id || '', name: cat?.name || it.name || '', qty: missing }));
    });
    setBatchRows(rows.length > 0 ? rows : [newRow()]);
  }, [fromRequestId, reqData, loadingAssets, catalog, assets]);

  useEffect(() => {
    if (activeTab === 'overdue') {
      fetchOverdue();
    }
  }, [activeTab]);

  const refId = (v) => (v && typeof v === 'object' ? v._id : v);
  const branchName = (id) => {
    if (id && typeof id === 'object') return id.name || id._id || '—';
    return branches.find((b) => b._id === id)?.name || id;
  };
  const userName = (id) => {
    if (id && typeof id === 'object') {
      const name = `${id.firstName || ''} ${id.lastName || ''}`.trim();
      return name ? `${name}${id.employeeCode ? ` (${id.employeeCode})` : ''}` : id._id || '—';
    }
    const u = users.find((u) => u._id === id);
    return u ? `${u.firstName} ${u.lastName} (${u.employeeCode})` : id;
  };
  const userDeptId = (u) => u?.departmentId?._id || u?.departmentId?.id || u?.departmentId || '';
  const deptName = (id) => {
    const rid = refId(id);
    if (id && typeof id === 'object' && id.name) return id.name;
    return departments.find((d) => d._id === rid)?.name || rid || '—';
  };
  const isDeptHeld = (a) => a?.holderType === 'DEPARTMENT' && !!a?.departmentId;
  const custodianCandidates = (deptId) => {
    const dept = departments.find((d) => d._id === deptId);
    const managers = (dept?.managerIds || []).map(refId);
    return users.filter((u) => u.isActive !== false && (userDeptId(u) === deptId || managers.includes(u._id)));
  };

  const statusInfo = (status) => {
    switch (status) {
      case 'ASSIGNED': return { label: 'ຖືກມອບໝາຍແລ້ວ', className: 'bg-blue-100 text-blue-700' };
      case 'UNDER_REPAIR': return { label: 'ກຳລັງສ້ອມແປງ', className: 'bg-amber-100 text-amber-700' };
      case 'RETIRED': return { label: 'ປົດລະວາງແລ້ວ', className: 'bg-gray-200 text-gray-600' };
      default: return { label: 'ວ່າງ', className: 'bg-green-100 text-green-700' };
    }
  };

  const handleExportAsset = async (a, cat, kind) => {
    setExportingAssetId(a._id);
    try {
      const fmt = (d) => (d ? new Date(d).toLocaleDateString() : '—');
      const fmtTime = (d) => (d ? new Date(d).toLocaleString() : '');
      const expired = a.warrantyExpiry && new Date(a.warrantyExpiry) < new Date();
      const fields = [
        ['Asset Tag', a.assetTag],
        ['ສະຖານະ', statusInfo(a.status).label],
        ['Serial Number', a.serialNumber || 'ບໍ່ມີ S/N'],
        ['ລາຍການ Catalog', a.catalogItemId ? `${refId(a.catalogItemId)} · ${cat?.name || ''}` : '—'],
        ['ໝວດໝູ່ / ປະເພດ', [cat?.category, a.type].filter(Boolean).join(' / ') || '—'],
        ['ສາຂາ', branchName(a.branchId) || '—'],
        ['ປະເພດຜູ້ຖື', isDeptHeld(a) ? 'ພະແນກ' : 'ບຸກຄົນ'],
        ...(isDeptHeld(a) ? [['ພະແນກ', deptName(a.departmentId)]] : []),
        [isDeptHeld(a) ? 'ຜູ້ຮັບຜິດຊອບ' : 'ຜູ້ຖືປັດຈຸບັນ', a.currentAssigneeId ? userName(a.currentAssigneeId) : '—'],
        ['ວັນທີຊື້', fmt(a.purchaseDate)],
        ['ລາຄາຊື້', a.purchasePrice != null ? Number(a.purchasePrice).toLocaleString() : '—'],
        ['ຮັບປະກັນຮອດ', `${fmt(a.warrantyExpiry)}${expired ? ' (ໝົດແລ້ວ)' : ''}`],
        ['ເພີ່ມເຂົ້າລະບົບ', fmt(a.createdAt)],
      ];
      const history = [...(a.assignmentHistory || [])].reverse().map((h) => ({
        assignee: userName(h.assigneeId),
        department: h.departmentId ? deptName(h.departmentId) : '',
        receivedBy: h.receivedById ? userName(h.receivedById) : '',
        assignedAt: fmtTime(h.assignedAt),
        returnedAt: h.returnedAt ? fmtTime(h.returnedAt) : 'ຍັງຖືຢູ່',
        note: h.note || '',
      }));
      const data = await buildAssetExport({
        assetId: a._id,
        title: a.assetTag,
        status: statusInfo(a.status).label,
        subtitle: a.catalogItemId ? `${refId(a.catalogItemId)} · ${cat?.name || a.type || ''}` : a.type || '',
        fields,
        history,
      });
      if (kind === 'csv') downloadAssetCsv(data);
      else printAssetPdf(data);
    } catch (err) {
      alert(err.response?.data?.msg || err.response?.data?.message || err.message || 'Export ບໍ່ສຳເລັດ');
    } finally {
      setExportingAssetId(null);
    }
  };



  const filteredAssets = assets.filter((a) => {
    if (statusFilter && a.status !== statusFilter) return false;
    if (branchFilter && refId(a.branchId) !== branchFilter) return false;
    if (holderTypeFilter === 'DEPARTMENT' && !isDeptHeld(a)) return false;
    if (holderTypeFilter === 'PERSON' && isDeptHeld(a)) return false;
    if (deptFilter && refId(a.departmentId) !== deptFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      const catName = catalog.find((c) => c._id === refId(a.catalogItemId))?.name || '';
      const hay = `${a.assetTag} ${a.serialNumber || ''} ${catName}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  const searchActive = !!search.trim();
  const folders = (() => {
    const map = new Map();
    filteredAssets.forEach((a) => {
      const key = refId(a.catalogItemId) || '__none';
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(a);
    });
    return [...map.entries()]
      .map(([key, list]) => ({
        key,
        name: catalog.find((c) => c._id === key)?.name || list[0]?.type || 'ບໍ່ລະບຸ Catalog',
        list: [...list].sort((x, y) => String(x.assetTag).localeCompare(String(y.assetTag))),
      }))
      .map((f) => {
        if (!receipts) return f;
        const byAsset = new Map();
        receipts.forEach((r) => (r.assetIds || []).forEach((id) => byAsset.set(String(id), r)));
        const gm = new Map();
        f.list.forEach((a) => {
          const r = byAsset.get(String(a._id));
          const k = r ? r._id : '__norcpt';
          if (!gm.has(k)) gm.set(k, { key: k, receipt: r || null, label: r ? (r.receiptNo || r._id) : 'ບໍ່ມີໃບຮັບເຄື່ອງ', list: [] });
          gm.get(k).list.push(a);
        });
        const groups = [...gm.values()].sort((x, y) => {
          if (!x.receipt) return 1;
          if (!y.receipt) return -1;
          return String(y.label).localeCompare(String(x.label));
        });
        groups.forEach((g, i) => { g.last = i === groups.length - 1; });
        return { ...f, groups };
      })
      .sort((x, y) => x.key.localeCompare(y.key));
  })();
  const toggleSub = (key) => setCollapsedSubs((prev) => {
    const next = new Set(prev);
    if (next.has(key)) next.delete(key); else next.add(key);
    return next;
  });
  const isFolderOpen = (key) => (searchActive ? !expandedFolders.has(key) : expandedFolders.has(key));
  const toggleFolder = (key) => setExpandedFolders((prev) => {
    const next = new Set(prev);
    if (next.has(key)) next.delete(key); else next.add(key);
    return next;
  });
  const allFoldersOpen = folders.length > 0 && folders.every((f) => isFolderOpen(f.key));
  const toggleAllFolders = () => {
    const allKeys = new Set(folders.map((f) => f.key));
    if (allFoldersOpen) setExpandedFolders(searchActive ? allKeys : new Set());
    else setExpandedFolders(searchActive ? new Set() : allKeys);
  };
  const toggleFolderSelect = (ids, allSelected) => setSelectedIds((prev) => {
    const next = new Set(prev);
    ids.forEach((id) => (allSelected ? next.delete(id) : next.add(id)));
    return next;
  });
  const detailAsset = detailAssetId ? assets.find((a) => a._id === detailAssetId) : null;

  useEffect(() => {
    if (!detailAssetId) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') setDetailAssetId(null); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [detailAssetId]);

  useEffect(() => {
    setSelectedIds(new Set());
  }, [search, statusFilter, branchFilter, holderTypeFilter, deptFilter]);

  const closeCreate = () => {
    setShowCreateModal(false);
    if (fromRequestId) navigate('/asset-registry', { replace: true });
  };

  const updateRow = (id, patch) => setBatchRows((rows) => rows.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  const removeRow = (id) => setBatchRows((rows) => (rows.length > 1 ? rows.filter((r) => r.id !== id) : rows));
  const isBlankRow = (r) => !r.catalogItemId && !(r.name || '').trim() && !(r.assetTag || '').trim();

  const handleRowCatalog = (id, value) => {
    const clean = value.trim().toLowerCase();
    const matched = assetCatalog.find((c) => (c.name || '').toLowerCase() === clean || (c._id || '').toLowerCase() === clean);
    updateRow(id, { catalogSearch: value, catalogItemId: matched ? matched._id : '', ...(matched ? { name: matched.name } : {}) });
  };

  const assetCountsFor = (catalogItemId) => {
    const list = assets.filter((a) => a.catalogItemId === catalogItemId && a.status !== 'RETIRED');
    return { total: list.length, available: list.filter((a) => a.status === 'AVAILABLE').length };
  };

  const togglePicked = (cid) => setPickerSelected((prev) => {
    const next = new Set(prev);
    if (next.has(cid)) next.delete(cid); else next.add(cid);
    return next;
  });

  const addPicked = () => {
    setBatchRows((prev) => {
      const have = new Set(prev.map((r) => r.catalogItemId).filter(Boolean));
      const keep = prev.filter((r) => !isBlankRow(r));
      const added = assetCatalog
        .filter((c) => pickerSelected.has(c._id) && !have.has(c._id))
        .map((c) => newRow({ catalogSearch: c.name, catalogItemId: c._id, name: c.name }));
      const merged = [...keep, ...added];
      return merged.length > 0 ? merged : [newRow()];
    });
    setPickerSelected(new Set());
    setPickerOpen(false);
  };

  const postAsset = async (payload) => {
    const res = await fetch(`${API_BASE_URL}/assets`, { method: 'POST', headers, body: JSON.stringify(payload) });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body?.msg || 'ບໍ່ສາມາດເພີ່ມຊັບສິນໄດ້');
    return unwrap(body);
  };

  const activeRows = batchRows.filter((r) => !isBlankRow(r));
  const batchTotal = activeRows.reduce((sum, r) => sum + Math.max(0, Math.floor(Number(r.qty) || 0)), 0);

  const submitBatch = async (e) => {
    e.preventDefault();
    if (!batchBranch) { setBatchError('ກະລຸນາເລືອກສາຂາ'); return; }
    if (activeRows.length === 0) { setBatchError('ກະລຸນາເພີ່ມຢ່າງໜ້ອຍ 1 ລາຍການ'); return; }
    for (let i = 0; i < activeRows.length; i += 1) {
      const r = activeRows[i];
      const qty = Math.floor(Number(r.qty) || 0);
      const label = `ແຖວທີ່ ${i + 1}`;
      if (!(r.name || '').trim()) { setBatchError(`${label}: ກະລຸນາໃສ່ຊື່/ປະເພດ`); return; }
      if (!r.catalogItemId && !(r.assetTag || '').trim()) { setBatchError(`${label}: ເລືອກລາຍການ Catalog (ສ້າງ Tag ອັດຕະໂນມັດ) ຫຼືໃສ່ Asset Tag`); return; }
      if (qty < 1) { setBatchError(`${label}: ຈຳນວນຕ້ອງຢ່າງໜ້ອຍ 1`); return; }
      const tagCount = parseTags(r.assetTag).length;
      if (tagCount > 0 && tagCount !== qty) { setBatchError(`${label}: ໃສ່ Asset Tag ${tagCount} ອັນ ແຕ່ຈຳນວນ ${qty} — ຕ້ອງເທົ່າກັນ`); return; }
    }
    if (batchTotal > MAX_BATCH) { setBatchError(`ສ້າງໄດ້ສູງສຸດ ${MAX_BATCH} ຊິ້ນຕໍ່ຄັ້ງ (ຕອນນີ້ ${batchTotal})`); return; }

    setBatchSubmitting(true);
    setBatchError('');
    const done = { ...batchDone };
    const results = [];
    let failed = false;
    for (const r of activeRows) {
      const want = Math.floor(Number(r.qty) || 1);
      const startOk = done[r.id] || 0;
      let ok = startOk;
      let errMsg = '';
      const tagList = parseTags(r.assetTag);
      while (ok < want) {
        try {
          await postAsset({
            assetTag: tagList[ok],
            catalogItemId: r.catalogItemId || undefined,
            type: r.name.trim(),
            branchId: batchBranch,
            purchaseDate: r.purchaseDate || batchPurchase || undefined,
            warrantyExpiry: r.warrantyExpiry || batchWarranty || undefined,
          });
          ok += 1;
          done[r.id] = ok;
        } catch (err) {
          errMsg = err.message;
          failed = true;
          break;
        }
      }
      results.push({ name: r.name || r.assetTag, ok, want, errMsg });
      if (failed) break;
    }
    setBatchDone(done);
    setBatchResult(results);
    if (failed) setBatchError('ມີບາງລາຍການສ້າງບໍ່ສຳເລັດ — ເບິ່ງສະຫຼຸບດ້ານລຸ່ມ, ແກ້ແລ້ວກົດບັນທຶກອີກຄັ້ງ (ສ່ວນທີ່ສ້າງແລ້ວຈະບໍ່ຖືກສ້າງຊ້ຳ)');
    else setBatchFinished(true);
    fetchAssets();
    fetchCatalog();
    setBatchSubmitting(false);
  };

  const openAssignModal = (asset) => {
    setAssignModalAsset(asset);
    setAssignUserId('');
    setSelectedDeptId('');
    setAssignNote('');
    setAssignError('');
    setAssignMode('PERSON');
    setCustodianId('');
    setProxyOn(false);
    setProxyCode('');
    setProxyLookup(null);
  };

  const submitAssign = (e) => {
    e.preventDefault();
    const toDept = assignMode === 'DEPARTMENT';
    if (toDept) {
      if (!selectedDeptId) return setAssignError('ກະລຸນາເລືອກພະແນກ');
      if (!custodianId) return setAssignError('ກະລຸນາເລືອກຜູ້ຮັບຜິດຊອບ');
      if (proxyOn && !(proxyLookup?.ok && proxyLookup.user)) return setAssignError('ກະລຸນາໃສ່ລະຫັດຜູ້ຮັບແທນໃຫ້ຖືກຕ້ອງ');
    } else if (!assignUserId) {
      setAssignError('ກະລຸນາເລືອກພະນັກງານ');
      return;
    }
    setAssignSubmitting(true);
    setAssignError('');
    fetch(`${API_BASE_URL}/assets/${assignModalAsset._id}/${toDept ? 'assign-department' : 'assign'}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify(
        toDept
          ? {
              departmentId: selectedDeptId,
              custodianId,
              receivedById: proxyOn ? proxyLookup.user._id : undefined,
              note: assignNote || undefined,
            }
          : { assigneeId: assignUserId, note: assignNote || undefined },
      ),
    })
      .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) {
          const m = body?.msg ?? body?.message;
          throw new Error((Array.isArray(m) ? m.join(' · ') : m) || 'ບໍ່ສາມາດມອບໝາຍໄດ້');
        }
        setAssignModalAsset(null);
        fetchAssets();
      })
      .catch((err) => setAssignError(err.message))
      .finally(() => setAssignSubmitting(false));
  };

  function callAction(id, path, method, body, confirmMsg) {
    if (confirmMsg && !confirm(confirmMsg)) return;
    setBusyId(id);
    fetch(`${API_BASE_URL}/assets/${id}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    })
      .then((res) => res.json().then((responseBody) => ({ ok: res.ok, responseBody })))
      .then(({ ok, responseBody }) => {
        if (!ok) throw new Error(responseBody?.msg || 'ດຳເນີນການບໍ່ສຳເລັດ');
        fetchAssets();
      })
      .catch((err) => alert(err.message))
      .finally(() => setBusyId(null));
  }

  const handleReturn = (a) => callAction(a._id, '/return', 'PATCH', {}, `ຢືນຢັນວ່າ ${a.assetTag} ຖືກສົ່ງຄືນແລ້ວ?`);
  const handleSetStatus = (a, status) => callAction(a._id, '/status', 'PATCH', { status });
  const handleDelete = (a) => callAction(a._id, '', 'DELETE', null, `ລຶບຊັບສິນ ${a.assetTag} ຖາວອນ? ບໍ່ສາມາດກູ້ຄືນໄດ້`);

  const selectableAssets = canSelect ? filteredAssets : [];
  const selectedAssets = filteredAssets.filter((a) => selectedIds.has(a._id));
  const allVisibleSelected =
    selectableAssets.length > 0 && selectableAssets.every((a) => selectedIds.has(a._id));
  const someVisibleSelected = selectableAssets.some((a) => selectedIds.has(a._id));

  const toggleSelect = (id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAllVisible = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allVisibleSelected) selectableAssets.forEach((a) => next.delete(a._id));
      else selectableAssets.forEach((a) => next.add(a._id));
      return next;
    });
  };

  const clearSelection = () => setSelectedIds(new Set());

  const runBulk = async (targets, buildReq, confirmMsg) => {
    if (targets.length === 0) return;
    if (confirmMsg && !confirm(confirmMsg)) return;
    setBulkOpBusy(true);
    const failed = [];
    for (const a of targets) {
      const { path, method, body } = buildReq(a);
      try {
        const res = await fetch(`${API_BASE_URL}/assets/${a._id}${path}`, {
          method,
          headers,
          body: body ? JSON.stringify(body) : undefined,
        });
        const rb = await res.json().catch(() => ({}));
        if (!res.ok) {
          const m = rb?.msg ?? rb?.message;
          throw new Error((Array.isArray(m) ? m.join(' · ') : m) || 'ບໍ່ສຳເລັດ');
        }
      } catch (err) {
        failed.push(`${a.assetTag}: ${err.message}`);
      }
    }
    setBulkOpBusy(false);
    clearSelection();
    fetchAssets();
    if (failed.length) alert(`ສຳເລັດ ${targets.length - failed.length}/${targets.length} ລາຍການ\n\n${failed.join('\n')}`);
  };

  const bulkRepair = () => {
    const t = selectedAssets.filter((a) => a.status !== 'RETIRED' && a.status !== 'UNDER_REPAIR');
    runBulk(t, () => ({ path: '/status', method: 'PATCH', body: { status: 'UNDER_REPAIR' } }), `ສົ່ງສ້ອມແປງ ${t.length} ລາຍການ?`);
  };
  const bulkFixed = () => {
    const t = selectedAssets.filter((a) => a.status === 'UNDER_REPAIR');
    runBulk(t, () => ({ path: '/status', method: 'PATCH', body: { status: 'AVAILABLE' } }), `ຢືນຢັນວ່າສ້ອມແລ້ວ ${t.length} ລາຍການ?`);
  };
  const bulkRetire = () => {
    const t = selectedAssets.filter((a) => a.status !== 'RETIRED');
    runBulk(t, () => ({ path: '/status', method: 'PATCH', body: { status: 'RETIRED' } }), `ປົດລະວາງ / ເລີກໃຊ້ ${t.length} ລາຍການ?`);
  };
  const bulkReturn = () => {
    const t = selectedAssets.filter((a) => a.status === 'ASSIGNED');
    runBulk(t, () => ({ path: '/return', method: 'PATCH', body: {} }), `ຢືນຢັນວ່າ ${t.length} ລາຍການຖືກສົ່ງຄືນແລ້ວ?`);
  };
  const bulkDelete = () => {
    runBulk(selectedAssets, () => ({ path: '', method: 'DELETE' }), `ລຶບຊັບສິນ ${selectedAssets.length} ລາຍການຖາວອນ? ບໍ່ສາມາດກູ້ຄືນໄດ້`);
  };
  const claimableCount = selectedAssets.filter((a) => a.status === 'AVAILABLE').length;
  const assignableSelected = selectedAssets.filter((a) => a.status === 'AVAILABLE');
  const submitBulkAssign = async (e) => {
    e.preventDefault();
    if (!bulkAssignUserId) { setBulkAssignError('ກະລຸນາເລືອກພະນັກງານ'); return; }
    setBulkAssignOpen(false);
    await runBulk(
      assignableSelected,
      () => ({ path: '/assign', method: 'PATCH', body: { assigneeId: bulkAssignUserId, note: bulkAssignNote || undefined } }),
    );
  };

  const openBulkClaim = () => {
    setBulkClaimError('');
    setBulkClaimResults(null);
    setBulkClaimCode('');
    setBulkClaimDept('');
    setBulkLookup({ state: 'idle', user: null });
    setBulkClaimOpen(true);
  };

  const closeBulkClaim = () => {
    setBulkClaimOpen(false);
    setBulkClaimError('');
    setBulkClaimResults(null);
    setBulkClaimCode('');
    setBulkLookup({ state: 'idle', user: null });
  };

  useEffect(() => {
    if (!proxyOn) return undefined;
    const code = proxyCode.trim();
    if (!code) {
      setProxyLookup(null);
      return undefined;
    }
    const t = setTimeout(() => {
      fetch(`${API_BASE_URL}/users/lookup/${encodeURIComponent(code)}`, { headers })
        .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
        .then(({ ok, body }) => {
          const u = unwrap(body);
          if (!ok || !u) return setProxyLookup({ ok: false, msg: 'ບໍ່ພົບລະຫັດພະນັກງານນີ້' });
          if (u.isActive === false) return setProxyLookup({ ok: false, msg: 'ບັນຊີນີ້ຖືກປິດໃຊ້ງານແລ້ວ' });
          const dept = departments.find((d) => d._id === selectedDeptId);
          const managers = (dept?.managerIds || []).map(refId);
          if (userDeptId(u) !== selectedDeptId && !managers.includes(u._id)) {
            return setProxyLookup({ ok: false, msg: 'ຜູ້ຮັບແທນຕ້ອງເປັນຄົນໃນພະແນກທີ່ເລືອກ' });
          }
          if (u._id === custodianId) return setProxyLookup({ ok: false, msg: 'ຜູ້ຮັບແທນຄືຜູ້ຮັບຜິດຊອບແລ້ວ — ບໍ່ຕ້ອງຕິກ "ຮັບແທນ"' });
          setProxyLookup({ ok: true, user: u });
        })
        .catch(() => setProxyLookup({ ok: false, msg: 'ກວດລະຫັດບໍ່ສຳເລັດ' }));
    }, 400);
    return () => clearTimeout(t);
  }, [proxyOn, proxyCode, selectedDeptId, custodianId]);

  const bulkCodeTrim = bulkClaimCode.trim();
  useEffect(() => {
    if (!bulkClaimOpen || !canAssign || !bulkCodeTrim) {
      setBulkLookup({ state: 'idle', user: null });
      return undefined;
    }
    setBulkLookup({ state: 'loading', user: null });
    const t = setTimeout(() => {
      fetch(`${API_BASE_URL}/users/lookup/${encodeURIComponent(bulkCodeTrim)}`, { headers })
        .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
        .then(({ ok, body }) => setBulkLookup(ok ? { state: 'found', user: unwrap(body) } : { state: 'notfound', user: null }))
        .catch(() => setBulkLookup({ state: 'error', user: null }));
    }, 400);
    return () => clearTimeout(t);
  }, [bulkCodeTrim, bulkClaimOpen, canAssign]);

  const confirmBulkClaim = () => {
    const targetAssets = filteredAssets.filter((a) => selectedIds.has(a._id) && a.status === 'AVAILABLE');
    if (targetAssets.length === 0) {
      setBulkClaimError('ກະລຸນາເລືອກຊັບສິນທີ່ສະຖານະ "ວ່າງ" ຢ່າງໜ້ອຍ 1 ລາຍການ');
      return;
    }
    const code = bulkClaimCode.trim();
    if (canAssign && !code) {
      setBulkClaimError('ກະລຸນາໃສ່ລະຫັດພະນັກງານຂອງຜູ້ມາຮັບ');
      return;
    }
    if (canAssign && bulkLookup.state !== 'found') {
      setBulkClaimError('ກະລຸນາກວດລະຫັດພະນັກງານໃຫ້ພົບກ່ອນກົດຢືນຢັນ');
      return;
    }
    setBulkClaimSubmitting(true);
    setBulkClaimError('');
    setBulkClaimResults(null);

    (async () => {
      const results = [];
      for (const a of targetAssets) {
        try {
          const res = await fetch(`${API_BASE_URL}/assets/${a._id}/claim`, {
            method: 'PATCH',
            headers,
            body: JSON.stringify({
              note: canAssign
                ? 'ມອບເຄື່ອງຫຼາຍລາຍການຢູ່ຄັງ — ຢືນຢັນຕົວຕົນດ້ວຍລະຫັດພະນັກງານ'
                : 'ຮັບເຄື່ອງຫຼາຍລາຍການດ້ວຍຕົນເອງ — ຢືນຢັນຕົວຕົນຂອງຜູ້ໃຊ້ທີ່ກຳລັງ login',
              ...(canAssign && code ? { assigneeCode: code } : {}),
            }),
          });
          const body = await res.json().catch(() => ({}));
          if (!res.ok) throw new Error(body?.msg || 'ບໍ່ສຳເລັດ');
          results.push({ assetTag: a.assetTag, ok: true });
        } catch (err) {
          results.push({ assetTag: a.assetTag, ok: false, message: /no approved supply request/i.test(err.message) ? 'ບໍ່ມີໃບຂໍທີ່ອະນຸມັດ' : err.message, noRequest: /no approved supply request/i.test(err.message) });
        }
      }
      setBulkClaimResults(results);
      setBulkClaimSubmitting(false);
      clearSelection();
      fetchAssets();
    })();
  };

  const vLine = (left, half) => (
    <span className="absolute w-px bg-gray-300 pointer-events-none" style={{ left, top: 0, bottom: half ? '50%' : 0 }} />
  );
  const hTick = (left, width) => (
    <span className="absolute h-px bg-gray-300 pointer-events-none" style={{ left, width, top: '50%' }} />
  );
  const renderAssetRow = (a, last, indent, grouped = false, parentLast = false) => {
    const info = statusInfo(a.status);
    const checkbox = canSelect ? (
      <input
        type="checkbox"
        aria-label={`ເລືອກ ${a.assetTag}`}
        checked={selectedIds.has(a._id)}
        onChange={() => toggleSelect(a._id)}
        className="rounded"
      />
    ) : null;
    return (
          <tr key={a._id} onClick={() => setDetailAssetId(a._id)} title="ກົດເພື່ອເບິ່ງລາຍລະອຽດ" className="hover:bg-amber-50/40 cursor-pointer">
            {grouped ? (
              <td className="p-3 relative" colSpan={2}>
                {!parentLast && vLine(20, false)}
                {vLine(56, last)}
                {hTick(56, 12)}
                <div className="flex items-center gap-2" style={{ paddingLeft: 60 }}>
                  <span className="inline-block w-4 shrink-0" onClick={(e) => e.stopPropagation()}>{checkbox}</span>
                  <span className="font-semibold text-gray-800">{a.assetTag}</span>
                  {a.serialNumber && <span className="text-xs text-gray-400">S/N {a.serialNumber}</span>}
                </div>
              </td>
            ) : (
              <>
                <td className="p-3" onClick={(e) => e.stopPropagation()}>{checkbox}</td>
                <td className="p-3">
                  <div className={`flex items-center gap-2 ${indent}`}>
                    <span className="font-mono text-gray-300 select-none">{last ? '└─' : '├─'}</span>
                    <span className="font-semibold text-gray-800">{a.assetTag}</span>
                    {a.serialNumber && <span className="text-xs text-gray-400">S/N {a.serialNumber}</span>}
                  </div>
                </td>
              </>
            )}
            <td className="p-3 text-gray-500">{branchName(a.branchId)}</td>
            <td className="p-3"><span className={`text-xs px-2.5 py-1 rounded-full font-medium ${info.className}`}>{info.label}</span></td>
            <td className="p-3 text-gray-500">
              {isDeptHeld(a) && a.currentAssigneeId ? (
                <div>
                  <span className="inline-block text-[11px] px-2 py-0.5 rounded-full bg-violet-100 text-violet-700 font-medium">ພະແນກ</span>{' '}
                  <span className="font-medium text-gray-700">{deptName(a.departmentId)}</span>
                  <div className="text-xs text-gray-400">ຜູ້ຮັບຜິດຊອບ: {userName(a.currentAssigneeId)}</div>
                </div>
              ) : (a.currentAssigneeId ? userName(a.currentAssigneeId) : '—')}
            </td>
            <td className="p-3 text-gray-500">{a.warrantyExpiry ? new Date(a.warrantyExpiry).toLocaleDateString() : '—'}</td>
            <td className="p-3 text-center">
              <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600">ເບິ່ງລາຍລະອຽດ<ChevronRight size={14} /></span>
            </td>
          </tr>
    );
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">ທະບຽນຊັບສິນບໍລິສັດ</h1>
            <p className="text-sm text-gray-500 mt-1">Laptop, ຈໍ, ບັດພະນັກງານ, ໂທລະສັບ — ຄົນລະສ່ວນຈາກການຂໍວັດສະດຸສິ້ນເປືອງ</p>
          </div>
          {(canCreate || canRead) && activeTab === 'registry' && (
            <div className="flex items-center gap-2">
              {canCreate && (
                <CsvImportButton
                  endpoint="/assets/bulk-import"
                  refresh={fetchAssets}
                  permitted={canCreate}
                  csvHint="CSV ຊັບສິນ: assetTag, type, branchId — ຈຳເປັນ; purchaseDate (YYYY-MM-DD), warrantyExpiry (YYYY-MM-DD) — ເພີ່ມໄດ້"
                />
              )}
              <CsvExportButton
                data={filteredAssets}
                filename="assets.csv"
                label="Export CSV"
                permitted={canRead}
                columns={[
                  { key: 'assetTag', label: 'assetTag' },
                  { key: 'type', label: 'type' },
                  { label: 'branch', value: (r) => branchName(r.branchId) },
                  { label: 'status', value: (r) => statusInfo(r.status).label },
                  { label: 'assignee', value: (r) => (r.currentAssigneeId ? userName(r.currentAssigneeId) : '') },
                  { label: 'holderDepartment', value: (r) => (isDeptHeld(r) ? deptName(r.departmentId) : '') },
                  { key: 'purchaseDate', label: 'purchaseDate' },
                  { key: 'warrantyExpiry', label: 'warrantyExpiry' },
                  { key: '_id', label: 'id' },
                ]}
              />
              {canCreate && (
                <button
                  onClick={openCreate}
                  className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-xl text-sm font-medium transition flex items-center justify-center gap-2 shadow-sm"
                >
                  <Plus size={18} /> <span>ເພີ່ມຊັບສິນ</span>
                </button>
              )}
            </div>
          )}
        </div>

        <div className="flex border-b border-gray-200 gap-6">
          <button
            onClick={() => setActiveTab('registry')}
            className={`pb-3 text-sm font-medium transition border-b-2 ${activeTab === 'registry' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            ທະບຽນຊັບສິນ
          </button>
          <button
            onClick={() => setActiveTab('overdue')}
            className={`pb-3 text-sm font-medium transition border-b-2 ${activeTab === 'overdue' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            ລາຍງານກວດສອບ — ຄ້າງສົ່ງຄືນ
            {overdue.length > 0 && (
              <span className="ml-1.5 text-xs bg-red-100 text-red-700 px-1.5 py-0.5 rounded-full">{overdue.length}</span>
            )}
          </button>
        </div>

        {activeTab === 'registry' && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm" style={{ overflow: 'clip' }}>
            <div className="sticky top-16 z-[5] bg-white rounded-t-2xl shadow-sm">
            <div className="p-4 border-b border-gray-100 flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="ຄົ້ນຫາ Asset Tag, S/N, ຊື່ລາຍການ..."
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); setExpandedFolders(new Set()); }}
                  className="w-full pl-9 pr-10 py-2 border border-gray-200 rounded-xl text-sm"
                />
                <button
                  type="button"
                  onClick={() => setScannerOpen(true)}
                  title="ສະແກນ QR / ບາໂຄ໊ດ ເພື່ອຄົ້ນຫາ"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg text-gray-500 hover:bg-gray-100"
                >
                  <Camera size={16} />
                </button>
              </div>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 text-sm">
                <option value="">ທຸກສະຖານະ</option>
                <option value="AVAILABLE">ວ່າງ</option>
                <option value="ASSIGNED">ຖືກມອບໝາຍແລ້ວ</option>
                <option value="UNDER_REPAIR">ກຳລັງສ້ອມແປງ</option>
                <option value="RETIRED">ປົດລະວາງແລ້ວ</option>
              </select>
              <select value={branchFilter} onChange={(e) => setBranchFilter(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 text-sm">
                <option value="">ທຸກສາຂາ</option>
                {branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
              </select>
              <select value={holderTypeFilter} onChange={(e) => setHolderTypeFilter(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 text-sm">
                <option value="">ຜູ້ຖືທັງໝົດ</option>
                <option value="PERSON">ຖືໂດຍບຸກຄົນ</option>
                <option value="DEPARTMENT">ຖືໂດຍພະແນກ</option>
              </select>
              <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 text-sm">
                <option value="">ທຸກພະແນກ</option>
                {departments.filter((d) => d.isActive !== false).map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}
              </select>
              <button
                type="button"
                onClick={toggleAllFolders}
                disabled={folders.length === 0}
                className="inline-flex items-center gap-1.5 px-3 py-2 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-40"
              >
                {allFoldersOpen ? <ChevronsUp size={16} /> : <ChevronsDown size={16} />}
                {allFoldersOpen ? 'ຫຍໍ້ທັງໝົດ' : 'ຂະຫຍາຍທັງໝົດ'}
              </button>
            </div>

            {selectedIds.size > 0 && (
              <div className="px-4 py-3 border-b border-gray-100 bg-blue-50/60 flex flex-wrap items-center justify-between gap-3">
                <div className="text-sm text-blue-800">
                  ເລືອກແລ້ວ <span className="font-semibold">{selectedIds.size}</span> ລາຍການ
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button type="button" onClick={clearSelection} className="px-3 py-1.5 text-xs text-gray-600 hover:bg-white rounded-lg transition">ລ້າງການເລືອກ</button>
                  {selectedAssets.length === 1 && (
                    <>
                      <DetailBtn onClick={() => setHistoryModalAsset(selectedAssets[0])} Icon={History} label="ປະຫວັດການມອບໝາຍ" tone="gray" />
                      <DetailBtn onClick={() => navigate(`/assets/${selectedAssets[0]._id}`)} Icon={ExternalLink} label="ເປີດໜ້າລາຍລະອຽດເຕັມ" tone="amber" />
                    </>
                  )}
                  <DetailBtn onClick={() => setBulkPrintOpen(true)} Icon={Barcode} label="Barcode / QR" tone="gray" disabled={bulkOpBusy} />
                  {canAssign && assignableSelected.length > 0 && (
                    <DetailBtn onClick={() => { setBulkAssignUserId(''); setBulkUserSearch(''); setBulkUserDept(''); setBulkAssignNote(''); setBulkAssignError(''); setBulkAssignOpen(true); }} Icon={UserCheck} label={`ມອບໝາຍ (${assignableSelected.length})`} tone="blue" disabled={bulkOpBusy} />
                  )}
                  {canAssign && selectedAssets.some((a) => a.status === 'AVAILABLE') && (
                    <DetailBtn onClick={openBulkClaim} Icon={UserCheck} label="ຢືນຢັນຮັບເຄື່ອງ" tone="blue" disabled={bulkOpBusy} />
                  )}
                  {canAssign && selectedAssets.some((a) => a.status === 'ASSIGNED') && (
                    <DetailBtn onClick={bulkReturn} Icon={Undo2} label="ຮັບຄືນ" tone="green" disabled={bulkOpBusy} />
                  )}
                  {canUpdate && selectedAssets.some((a) => a.status !== 'RETIRED' && a.status !== 'UNDER_REPAIR') && (
                    <DetailBtn onClick={bulkRepair} Icon={Wrench} label="ສົ່ງສ້ອມແປງ" tone="amber" disabled={bulkOpBusy} />
                  )}
                  {canUpdate && selectedAssets.some((a) => a.status === 'UNDER_REPAIR') && (
                    <DetailBtn onClick={bulkFixed} Icon={CheckCircle2} label="ສ້ອມແລ້ວ" tone="green" disabled={bulkOpBusy} />
                  )}
                  {canUpdate && selectedAssets.some((a) => a.status !== 'RETIRED') && (
                    <DetailBtn onClick={bulkRetire} Icon={Archive} label="ປົດລະວາງ / ເລີກໃຊ້" tone="gray" disabled={bulkOpBusy} />
                  )}
                  {canDelete && (
                    <DetailBtn onClick={bulkDelete} Icon={Trash2} label="ລຶບ" tone="red" disabled={bulkOpBusy} />
                  )}
                </div>
              </div>
            )}

            </div>

            {assetsError && <div className="p-4 text-sm text-red-600 flex items-center gap-2"><AlertCircle size={16} />{assetsError}</div>}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-gray-50 text-gray-500">
                  <tr>
                    <th className="p-3 w-10">
                      {canSelect && <input
                        type="checkbox"
                        aria-label="ເລືອກທັງໝົດ"
                        checked={allVisibleSelected}
                        ref={(el) => { if (el) el.indeterminate = !allVisibleSelected && someVisibleSelected; }}
                        onChange={toggleSelectAllVisible}
                        disabled={selectableAssets.length === 0}
                        className="rounded"
                      />}
                    </th>
                    <th className="p-3 font-medium">Asset Tag</th>
                    <th className="p-3 font-medium">ສາຂາ</th>
                    <th className="p-3 font-medium">ສະຖານະ</th>
                    <th className="p-3 font-medium">ຜູ້ຖືກມອບໝາຍ</th>
                    <th className="p-3 font-medium">ວັນໝົດປະກັນ</th>
                    <th className="p-3 font-medium text-center">ລາຍລະອຽດ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {loadingAssets && (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-sm text-gray-500">ກຳລັງໂຫຼດ...</td>
                    </tr>
                  )}
                  {!loadingAssets && filteredAssets.length === 0 && (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-sm text-gray-500">ບໍ່ພົບຊັບສິນທີ່ຄ້າຍຄື</td>
                    </tr>
                  )}
                  {folders.map((f) => {
                    const open = isFolderOpen(f.key);
                    const availIds = f.list.map((a) => a._id);
                    const allSel = availIds.length > 0 && availIds.every((id) => selectedIds.has(id));
                    const counts = f.list.reduce((m, a) => ({ ...m, [a.status]: (m[a.status] || 0) + 1 }), {});
                    return (
                      <Fragment key={f.key}>
                        <tr onClick={() => toggleFolder(f.key)} className="bg-gray-50/80 hover:bg-amber-50/50 cursor-pointer">
                          <td className="p-3" onClick={(e) => e.stopPropagation()}>
                            {canSelect && availIds.length > 0 && (
                              <input
                                type="checkbox"
                                aria-label={`ເລືອກທີ່ວ່າງທັງໝົດໃນ ${f.key}`}
                                checked={allSel}
                                onChange={() => toggleFolderSelect(availIds, allSel)}
                                className="rounded"
                              />
                            )}
                          </td>
                          <td className="p-3" colSpan={2}>
                            <div className="flex items-center gap-2">
                              {open ? <ChevronDown size={16} className="text-gray-400" /> : <ChevronRight size={16} className="text-gray-400" />}
                              {open ? <FolderOpen size={18} className="text-amber-500" /> : <Folder size={18} className="text-amber-500" />}
                              <CatalogThumb url={catalog.find((c) => c._id === f.key)?.imageUrl} name={f.name} size={36} />
                              <span className="font-semibold text-gray-900">{f.key === '__none' ? '—' : f.key}</span>
                              <span className="text-gray-600">{f.name}</span>
                            </div>
                          </td>
                          <td className="p-3" colSpan={3}>
                            <div className="flex flex-wrap gap-1.5">
                              {Object.entries(counts).map(([st, n]) => {
                                const si = statusInfo(st);
                                return <span key={st} className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${si.className}`}>{si.label} {n}</span>;
                              })}
                            </div>
                          </td>
                          <td className="p-3 text-center text-xs font-medium text-gray-500">{f.list.length} ລາຍການ</td>
                        </tr>
                        {open && (f.groups
                          ? f.groups.map((g) => {
                              const subKey = `${f.key}::${g.key}`;
                              const subOpen = !collapsedSubs.has(subKey);
                              const gAvail = g.list.map((a) => a._id);
                              const gAllSel = gAvail.length > 0 && gAvail.every((id) => selectedIds.has(id));
                              return (
                                <Fragment key={subKey}>
                                  <tr onClick={() => toggleSub(subKey)} className="bg-white hover:bg-amber-50/40 cursor-pointer">
                                    <td className="p-3 relative" colSpan={6}>
                                      {vLine(20, g.last)}
                                      {hTick(20, 12)}
                                      <div className="flex items-center gap-2" style={{ paddingLeft: 26 }}>
                                        <span className="inline-block w-4 shrink-0" onClick={(e) => e.stopPropagation()}>
                                          {canSelect && gAvail.length > 0 && (
                                            <input
                                              type="checkbox"
                                              aria-label={`ເລືອກທີ່ວ່າງທັງໝົດໃນ ${g.label}`}
                                              checked={gAllSel}
                                              onChange={() => toggleFolderSelect(gAvail, gAllSel)}
                                              className="rounded"
                                            />
                                          )}
                                        </span>
                                        {subOpen ? <ChevronDown size={14} className="text-gray-400" /> : <ChevronRight size={14} className="text-gray-400" />}
                                        {subOpen ? <FolderOpen size={16} className={g.receipt ? 'text-emerald-500' : 'text-gray-400'} /> : <Folder size={16} className={g.receipt ? 'text-emerald-500' : 'text-gray-400'} />}
                                        <span className={`font-semibold ${g.receipt ? 'text-gray-800' : 'text-gray-500'}`}>{g.label}</span>
                                        {g.receipt && (
                                          <span className="text-xs text-gray-400">
                                            {g.receipt.receivedDate ? new Date(g.receipt.receivedDate).toLocaleDateString() : ''}
                                            {g.receipt.vendor ? ` · ${g.receipt.vendor}` : ''}
                                          </span>
                                        )}
                                      </div>
                                      {g.receipt && (
                                        <div className="flex flex-wrap items-center gap-1.5 mt-1 text-[11px]" style={{ paddingLeft: 50 }}>
                                          <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">ຈຳນວນ {g.receipt.quantity ?? g.list.length} ໜ່ວຍ</span>
                                          {g.receipt.unitPrice != null && (
                                            <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">ລາຄາ/ໜ່ວຍ {Number(g.receipt.unitPrice).toLocaleString()}</span>
                                          )}
                                          {g.receipt.totalPrice != null && (
                                            <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-medium">ລວມ {Number(g.receipt.totalPrice).toLocaleString()}</span>
                                          )}
                                          {g.receipt.createdBy && typeof g.receipt.createdBy === 'object' && (
                                            <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700">ບັນທຶກໂດຍ {userName(g.receipt.createdBy)}</span>
                                          )}
                                        </div>
                                      )}
                                    </td>
                                    <td className="p-3 text-center text-xs font-medium text-gray-500">{g.list.length} ລາຍການ</td>
                                  </tr>
                                  {subOpen && g.list.map((a, i) => renderAssetRow(a, i === g.list.length - 1, '', true, g.last))}
                                </Fragment>
                              );
                            })
                          : f.list.map((a, i) => renderAssetRow(a, i === f.list.length - 1, 'pl-7')))}
                      </Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'overdue' && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-gray-100">
              <div className="font-bold text-gray-800">ຊັບສິນທີ່ຍັງບໍ່ໄດ້ສົ່ງຄືນ</div>
              <p className="text-xs text-gray-500 mt-0.5">ພະນັກງານທີ່ຖືກປິດການໃຊ້ງານ (offboard/ໂອນຍ້າຍ) ແຕ່ຍັງບໍ່ໄດ້ສົ່ງອຸປະກອນຄືນ</p>
            </div>
            {overdueError && <div className="p-4 text-sm text-red-600">{overdueError}</div>}
            {loadingOverdue ? (
              <div className="p-6 text-center text-sm text-gray-500">ກຳລັງໂຫຼດ...</div>
            ) : overdue.length === 0 && !overdueError ? (
              <div className="p-6 text-center text-sm text-gray-500">ບໍ່ມີຊັບສິນຄ້າງສົ່ງຄືນ</div>
            ) : (
              <div className="divide-y divide-gray-100">
                {overdue.map((o) => (
                  <div key={o._id} className="p-4 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-red-50 text-red-500 flex items-center justify-center shrink-0">
                        <AlertTriangle size={16} />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-800">{o.assetTag} — {o.type}</div>
                        <div className="text-xs text-gray-500">
                          ຄ້າງຢູ່ກັບ {o.assignee?.email} (ພະນັກງານປິດການໃຊ້ງານແລ້ວ) — ສາຂາ {branchName(o.branchId)}
                        </div>
                      </div>
                    </div>
                    {canAssign && (
                      <button
                        onClick={() => handleReturn({ _id: o._id, assetTag: o.assetTag })}
                        disabled={busyId === o._id}
                        className="text-xs px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg font-medium transition disabled:opacity-50"
                      >
                        ໝາຍວ່າຮັບຄືນແລ້ວ
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {showCreateModal && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
            <form onSubmit={submitBatch} className="bg-white rounded-2xl p-6 w-full max-w-2xl space-y-4 max-h-[92vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-800">
                  {fromRequestId ? `ເພີ່ມຊັບສິນຕາມໃບຂໍ ${fromRequestId}` : 'ເພີ່ມຊັບສິນໃໝ່'}
                </h2>
                <button type="button" onClick={closeCreate} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
              </div>

              {fromRequestId && (
                <p className="text-xs text-gray-500">
                  {reqError ? <span className="text-red-600">{reqError}</span> : reqData ? 'ເຕີມສະເພາະລາຍການທີ່ຂາດໃນທະບຽນໃຫ້ແລ້ວ (ຂໍ − ວ່າງ) — ແກ້ຈຳນວນໄດ້.' : 'ກຳລັງໂຫຼດໃບຂໍ...'}
                </p>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">ສາຂາ * (ໃຊ້ກັບທຸກແຖວ)</label>
                  <select value={batchBranch} onChange={(e) => setBatchBranch(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm">
                    <option value="">-- ເລືອກສາຂາ --</option>
                    {branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">ວັນທີຊື້ (ທາງເລືອກ)</label>
                  <input type="date" value={batchPurchase} onChange={(e) => setBatchPurchase(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">ໝົດປະກັນ (ທາງເລືອກ)</label>
                  <input type="date" value={batchWarranty} onChange={(e) => setBatchWarranty(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm" />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold text-gray-700">ລາຍການຊັບສິນ</div>
                <div className="flex items-center gap-3 text-xs">
                  <button type="button" onClick={() => setPickerOpen((v) => !v)} className="text-blue-600 hover:underline">
                    {pickerOpen ? 'ປິດການເລືອກຈາກ Catalog' : '☑ ເລືອກຫຼາຍລາຍການຈາກ Catalog'}
                  </button>
                  <button type="button" onClick={() => setBatchRows((rows) => [...rows, newRow()])} className="text-amber-600 hover:underline">+ ເພີ່ມລາຍການອື່ນ</button>
                </div>
              </div>

              {pickerOpen && (
                <div className="border border-blue-200 bg-blue-50/40 rounded-xl p-3 space-y-2">
                  <input
                    type="text"
                    value={pickerSearch}
                    onChange={(e) => setPickerSearch(e.target.value)}
                    placeholder="ຄົ້ນຫາຊື່ ຫຼື ລະຫັດ..."
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white"
                  />
                  <div className="max-h-48 overflow-y-auto bg-white border border-gray-100 rounded-lg divide-y divide-gray-100">
                    {assetCatalog
                      .filter((c) => {
                        const q = pickerSearch.trim().toLowerCase();
                        return !q || (c.name || '').toLowerCase().includes(q) || (c._id || '').toLowerCase().includes(q) || (c.category || '').toLowerCase().includes(q);
                      })
                      .map((c) => {
                        const cnt = assetCountsFor(c._id);
                        return (
                          <label key={c._id} className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-gray-50">
                            <input type="checkbox" checked={pickerSelected.has(c._id)} onChange={() => togglePicked(c._id)} />
                            <div className="flex-1 min-w-0">
                              <div className="text-sm text-gray-800">{c.name} <span className="text-xs text-gray-400">({c._id})</span></div>
                              <div className="text-xs text-gray-500">ໃນທະບຽນ {cnt.total} (ວ່າງ {cnt.available}) · ສະຕ໊ອກ Catalog {c.stockQty}</div>
                            </div>
                          </label>
                        );
                      })}
                    {assetCatalog.length === 0 && <div className="px-3 py-3 text-xs text-gray-400">ບໍ່ມີລາຍການ Catalog ປະເພດ ASSET — ສ້າງ/ແກ້ປະເພດໃນ Supply Catalog ກ່ອນ</div>}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">ເລືອກແລ້ວ {pickerSelected.size} ລາຍການ</span>
                    <button type="button" disabled={pickerSelected.size === 0} onClick={addPicked} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-medium disabled:opacity-40">ເພີ່ມເຂົ້າລາຍການ</button>
                  </div>
                </div>
              )}

              <datalist id="asset-catalog-options">
                {assetCatalog.map((c) => (
                  <option key={c._id} value={c.name}>{c._id} — {c.category}</option>
                ))}
              </datalist>

              <div className="space-y-3">
                {batchRows.map((r, idx) => {
                  const cat = r.catalogItemId ? catalog.find((c) => c._id === r.catalogItemId) : null;
                  const qty = Math.max(0, Math.floor(Number(r.qty) || 0));
                  const cnt = cat ? assetCountsFor(cat._id) : null;
                  const availAfter = cnt ? cnt.available + qty : 0;
                  const doneN = batchDone[r.id] || 0;
                  return (
                    <div key={r.id} className="border border-gray-200 bg-gray-50 rounded-xl p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-gray-600">ແຖວທີ່ {idx + 1}{doneN > 0 && <span className="ml-2 text-emerald-600">✓ ສ້າງແລ້ວ {doneN}</span>}</span>
                        {batchRows.length > 1 && (
                          <button type="button" onClick={() => removeRow(r.id)} className="text-xs text-red-500 hover:underline">ລຶບ</button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                        <div className="sm:col-span-3">
                          <label className="block text-xs text-gray-500 mb-1">ຄົ້ນຫາ/ເລືອກຈາກ Supply Catalog</label>
                          <input
                            type="text"
                            list="asset-catalog-options"
                            value={r.catalogSearch}
                            onChange={(e) => handleRowCatalog(r.id, e.target.value)}
                            placeholder="ພິມຊື່ອຸປະກອນ ຫຼື SC001, SC002..."
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-gray-500 mb-1">ຈຳນວນ *</label>
                          <input type="number" min={1} max={MAX_BATCH} value={r.qty} onChange={(e) => updateRow(r.id, { qty: e.target.value })} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white" />
                        </div>
                      </div>
                      {cat ? (
                        <div className="text-xs text-gray-500">
                          ✓ {cat.name} ({cat._id}) — Asset Tag ສ້າງໃຫ້ອັດຕະໂນມັດ · ໃນທະບຽນ {cnt.total} (ວ່າງ {cnt.available}) · ສະຕ໊ອກ Catalog {cat.stockQty}
                          {availAfter > cat.stockQty && (
                            <span className="block text-gray-400">ຫຼັງສ້າງ ສະຕ໊ອກ Catalog ຈະບວກ +{qty} ອັດຕະໂນມັດ (backend ນັບຈາກຊັບສິນວ່າງ)</span>
                          )}
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div>
                            <label className="block text-xs text-gray-500 mb-1">ຊື່/ປະເພດ *</label>
                            <input type="text" value={r.name} onChange={(e) => updateRow(r.id, { name: e.target.value })} placeholder="Laptop, ຈໍ, ບັດພະນັກງານ..." className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white" />
                          </div>
                          <div>
                            <label className="block text-xs text-gray-500 mb-1">Asset Tag (ບໍ່ມີ Catalog = ຕ້ອງໃສ່, 1 ແຖວ/ຄອມມາ ຕໍ່ 1 ຊິ້ນ) — {parseTags(r.assetTag).length}/{Math.floor(Number(r.qty) || 0)}</label>
                            <textarea rows={Math.min(5, Math.max(2, Math.floor(Number(r.qty) || 1)))} value={r.assetTag} onChange={(e) => updateRow(r.id, { assetTag: e.target.value })} placeholder={'A-1042\nA-1043'} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white font-mono" />
                          </div>
                        </div>
                      )}
                      <div>
                        <button type="button" onClick={() => updateRow(r.id, { showDates: !r.showDates })} className="text-xs text-blue-600 hover:underline">
                          {r.showDates ? 'ໃຊ້ວັນທີຮ່ວມ' : 'ປັບວັນທີຊື້/ປະກັນຂອງແຖວນີ້'}
                        </button>
                        {r.showDates && (
                          <div className="grid grid-cols-2 gap-2 mt-1">
                            <input type="date" value={r.purchaseDate} onChange={(e) => updateRow(r.id, { purchaseDate: e.target.value })} className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs bg-white" />
                            <input type="date" value={r.warrantyExpiry} onChange={(e) => updateRow(r.id, { warrantyExpiry: e.target.value })} className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs bg-white" />
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="text-xs text-gray-500">ລວມ {batchTotal} ຊິ້ນ (ສູງສຸດ {MAX_BATCH} ຕໍ່ຄັ້ງ)</div>

              {batchResult && (
                <div className="text-xs bg-gray-50 border border-gray-100 rounded-lg px-3 py-2 space-y-1">
                  {batchResult.map((r, i) => (
                    <div key={i}>
                      <div className={r.errMsg ? 'text-red-600' : 'text-emerald-700'}>
                        {r.errMsg ? '✕' : '✓'} {r.name}: ສ້າງແລ້ວ {r.ok}/{r.want}{r.errMsg ? ` — ${r.errMsg}` : ''}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {batchError && <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{batchError}</div>}

              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={closeCreate} className="px-4 py-2 text-sm text-gray-600">{batchFinished ? 'ປິດ' : 'ຍົກເລີກ'}</button>
                {!batchFinished && (
                  <button type="submit" disabled={batchSubmitting || batchTotal < 1} className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-medium disabled:opacity-50">
                    {batchSubmitting ? 'ກຳລັງບັນທຶກ...' : `ບັນທຶກທັງໝົດ (${batchTotal} ຊິ້ນ)`}
                  </button>
                )}
              </div>
            </form>
          </div>
        )}

        {detailAsset && (() => {
          const a = detailAsset;
          const info = statusInfo(a.status);
          const cat = catalog.find((c) => c._id === refId(a.catalogItemId));
          const busy = busyId === a._id;
          const expired = a.warrantyExpiry && new Date(a.warrantyExpiry) < new Date();
          const hist = [...(a.assignmentHistory || [])].reverse();
          const fmt = (d) => (d ? new Date(d).toLocaleDateString() : '—');
          return (
            <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDetailAssetId(null)}>
              <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[92vh] shadow-xl flex flex-col overflow-hidden" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
                <div className="flex items-start justify-between px-6 pt-5 pb-3">
                  <div className="flex items-center gap-3">
                    <CatalogThumb url={cat?.imageUrl} name={cat?.name || a.type} size={56} />
                  <div>
                    <div className="flex items-center gap-3">
                      <h2 className="text-lg font-bold text-gray-800">{a.assetTag}</h2>
                      <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${info.className}`}>{info.label}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">{a.catalogItemId ? `${refId(a.catalogItemId)} · ${cat?.name || a.type || ''}` : a.type || ''}</p>
                  </div>
                  </div>
                  <button type="button" onClick={() => setDetailAssetId(null)} className="text-gray-400 hover:text-gray-600" aria-label="ປິດ"><X size={20} /></button>
                </div>
                <div className="flex-1 overflow-y-auto px-6 pb-5 space-y-4">
                  <div className="rounded-xl border border-gray-100 bg-gray-50/60 p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
                    <DetailField label="Asset Tag">{a.assetTag}</DetailField>
                    <DetailField label="Serial Number">{a.serialNumber || 'ບໍ່ມີ S/N'}</DetailField>
                    <DetailField label="ລາຍການ Catalog">{a.catalogItemId ? `${refId(a.catalogItemId)} · ${cat?.name || ''}` : '—'}</DetailField>
                    <DetailField label="ໝວດໝູ່ / ປະເພດ">{[cat?.category, a.type].filter(Boolean).join(' / ') || '—'}</DetailField>
                    <DetailField label="ສາຂາ">{branchName(a.branchId) || '—'}</DetailField>
                    <DetailField label="ປະເພດຜູ້ຖື">{isDeptHeld(a) ? 'ພະແນກ' : 'ບຸກຄົນ'}</DetailField>
                    {isDeptHeld(a) && <DetailField label="ພະແນກ">{deptName(a.departmentId)}</DetailField>}
                    <DetailField label={isDeptHeld(a) ? 'ຜູ້ຮັບຜິດຊອບ' : 'ຜູ້ຖືປັດຈຸບັນ'}>{a.currentAssigneeId ? userName(a.currentAssigneeId) : '—'}</DetailField>
                    <DetailField label="ວັນທີຊື້">{fmt(a.purchaseDate)}</DetailField>
                    <DetailField label="ລາຄາຊື້">{a.purchasePrice != null ? Number(a.purchasePrice).toLocaleString() : '—'}</DetailField>
                    <DetailField label="ຮັບປະກັນຮອດ">
                      {fmt(a.warrantyExpiry)}
                      {expired && <span className="ml-1 text-xs text-red-600">(ໝົດແລ້ວ)</span>}
                    </DetailField>
                    <DetailField label="ເພີ່ມເຂົ້າລະບົບ">{fmt(a.createdAt)}</DetailField>
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-gray-600 mb-2">ຈັດການຊັບສິນນີ້</div>
                    <div className="flex flex-wrap gap-2">
                      <DetailBtn onClick={() => setHistoryModalAsset(a)} Icon={History} label="ປະຫວັດການມອບໝາຍ" tone="gray" />
                      <DetailBtn onClick={() => setBarcodeModalAsset(a)} Icon={Barcode} label="Barcode / QR" tone="gray" />
                      {canAssign && a.status === 'AVAILABLE' && (
                        <DetailBtn onClick={() => openAssignModal(a)} Icon={UserCheck} label="ມອບໝາຍ" tone="blue" disabled={busy} />
                      )}
                      {canAssign && a.status === 'ASSIGNED' && (
                        <DetailBtn onClick={() => handleReturn(a)} Icon={Undo2} label="ຮັບຄືນ" tone="green" disabled={busy} />
                      )}
                      {canUpdate && a.status !== 'RETIRED' && a.status !== 'UNDER_REPAIR' && (
                        <DetailBtn onClick={() => handleSetStatus(a, 'UNDER_REPAIR')} Icon={Wrench} label="ສົ່ງສ້ອມແປງ" tone="amber" disabled={busy} />
                      )}
                      {canUpdate && a.status === 'UNDER_REPAIR' && (
                        <DetailBtn onClick={() => handleSetStatus(a, 'AVAILABLE')} Icon={CheckCircle2} label="ສ້ອມແລ້ວ" tone="green" disabled={busy} />
                      )}
                      {canUpdate && a.status !== 'RETIRED' && (
                        <DetailBtn onClick={() => handleSetStatus(a, 'RETIRED')} Icon={Archive} label="ປົດລະວາງ / ເລີກໃຊ້" tone="gray" disabled={busy} />
                      )}
                      {canDelete && (
                        <DetailBtn onClick={() => handleDelete(a)} Icon={Trash2} label="ລຶບ" tone="red" disabled={busy} />
                      )}
                      <DetailBtn onClick={() => navigate(`/assets/${a._id}`)} Icon={ExternalLink} label="ເປີດໜ້າລາຍລະອຽດເຕັມ" tone="amber" />
                      <DetailBtn onClick={() => handleExportAsset(a, cat, 'pdf')} Icon={FileText} label="ສົ່ງອອກ PDF" tone="gray" disabled={exportingAssetId === a._id} />
                      <DetailBtn onClick={() => handleExportAsset(a, cat, 'csv')} Icon={FileSpreadsheet} label="ສົ່ງອອກ CSV" tone="gray" disabled={exportingAssetId === a._id} />
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-gray-600 mb-2">ໄທມ໌ໄລນ໌ — ເຂົ້າສາງ / ໃຜຮັບ / ໃຜຖື</div>
                    <AssetTimeline assetId={a._id} />
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-gray-600 mb-2">ປະຫວັດການມອບໝາຍ ({hist.length})</div>
                    {hist.length === 0 ? (
                      <p className="text-sm text-gray-400">ຍັງບໍ່ເຄີຍຖືກມອບໝາຍ</p>
                    ) : (
                      <div className="space-y-2">
                        {hist.map((h, i) => (
                          <div key={h._id || i} className="border border-gray-100 rounded-xl p-3 text-sm">
                            <div className="font-medium text-gray-800">
                              {userName(h.assigneeId)}
                              {h.departmentId && <span className="ml-2 text-[11px] px-2 py-0.5 rounded-full bg-violet-100 text-violet-700">ພະແນກ {deptName(h.departmentId)}</span>}
                            </div>
                            <div className="text-xs text-gray-500 mt-0.5">
                              {h.assignedAt ? new Date(h.assignedAt).toLocaleString() : '—'} —{' '}
                              {h.returnedAt ? new Date(h.returnedAt).toLocaleString() : <span className="text-blue-600 font-medium">ຍັງຖືຢູ່</span>}
                            </div>
                            {h.receivedById && <div className="text-xs text-gray-500 mt-0.5">ຮັບແທນໂດຍ {userName(h.receivedById)}</div>}
                            {h.note && <div className="text-xs text-gray-500 mt-1 italic">"{h.note}"</div>}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {assignModalAsset && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
            <form onSubmit={submitAssign} className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-800">ມອບໝາຍ {assignModalAsset.assetTag}</h2>
              </div>
              <div className="flex gap-2">
                <button type="button" onClick={() => setAssignMode('PERSON')} className={`flex-1 px-3 py-2 rounded-xl text-sm font-medium border ${assignMode === 'PERSON' ? 'bg-amber-50 border-amber-400 text-amber-700' : 'border-gray-200 text-gray-500'}`}>ມອບໃຫ້ບຸກຄົນ</button>
                <button type="button" onClick={() => setAssignMode('DEPARTMENT')} className={`flex-1 px-3 py-2 rounded-xl text-sm font-medium border ${assignMode === 'DEPARTMENT' ? 'bg-violet-50 border-violet-400 text-violet-700' : 'border-gray-200 text-gray-500'}`}>ມອບໃຫ້ພະແນກ</button>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">ພະແນກ{assignMode === 'DEPARTMENT' && <span className="text-red-500"> *</span>}</label>
                <select value={selectedDeptId} onChange={(e) => { setSelectedDeptId(e.target.value); setAssignUserId(""); setCustodianId(''); setProxyLookup(null); }} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm">
                  <option value="">-- ເລືອກພະແນກ --</option>
                  {departments.filter((d) => d.isActive !== false).map((d) => (
                    <option key={d._id} value={d._id}>{d.name}</option>
                  ))}
                </select>
              </div>
              {assignMode === 'PERSON' ? (
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">ພະນັກງານ</label>
                  <select required value={assignUserId} onChange={(e) => setAssignUserId(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm">
                    <option value="">-- ເລືອກພະນັກງານ --</option>
                    {users.filter((u) => u.isActive && (!selectedDeptId || userDeptId(u) === selectedDeptId)).map((u) => (
                      <option key={u._id} value={u._id}>{u.firstName} {u.lastName} ({u.employeeCode})</option>
                    ))}
                  </select>
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">ຜູ້ຮັບຜິດຊອບ (ຫົວໜ້າ ຫຼື ຜູ້ທີ່ພະແນກມອບໝາຍ) <span className="text-red-500">*</span></label>
                    <select value={custodianId} onChange={(e) => { setCustodianId(e.target.value); setProxyLookup(null); }} disabled={!selectedDeptId} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm disabled:bg-gray-50">
                      <option value="">{selectedDeptId ? '-- ເລືອກຜູ້ຮັບຜິດຊອບ --' : 'ເລືອກພະແນກກ່ອນ'}</option>
                      {custodianCandidates(selectedDeptId).map((u) => (
                        <option key={u._id} value={u._id}>{u.firstName} {u.lastName} ({u.employeeCode})</option>
                      ))}
                    </select>
                  </div>
                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input type="checkbox" checked={proxyOn} onChange={(e) => { setProxyOn(e.target.checked); setProxyCode(''); setProxyLookup(null); }} />
                    ມີຜູ້ມາຮັບແທນ (ຜູ້ຮັບຜິດຊອບບໍ່ຢູ່)
                  </label>
                  {proxyOn && (
                    <div className="space-y-1">
                      <input
                        type="text"
                        value={proxyCode}
                        onChange={(e) => setProxyCode(e.target.value)}
                        placeholder="ລະຫັດພະນັກງານຂອງຜູ້ມາຮັບແທນ"
                        className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm"
                      />
                      {proxyLookup?.ok && proxyLookup.user && (
                        <div className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
                          ✓ {proxyLookup.user.firstName} {proxyLookup.user.lastName} · {deptName(proxyLookup.user.departmentId)}
                        </div>
                      )}
                      {proxyLookup && !proxyLookup.ok && (
                        <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{proxyLookup.msg}</div>
                      )}
                      <p className="text-[11px] text-gray-400">ຜູ້ຮັບຜິດຊອບເຄື່ອງຍັງຄືເດີມ ຜູ້ຮັບແທນຖືກບັນທຶກໃນປະຫວັດເທົ່ານັ້ນ</p>
                    </div>
                  )}
                </>
              )}
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">ໝາຍເຫດ (ບໍ່ບັງຄັບ)</label>
                <input type="text" value={assignNote} onChange={(e) => setAssignNote(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm" />
              </div>
              {assignError && <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{assignError}</div>}
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setAssignModalAsset(null)} className="px-4 py-2 text-sm text-gray-600">ຍົກເລີກ</button>
                <button type="submit" disabled={assignSubmitting} className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-medium disabled:opacity-50">
                  {assignSubmitting ? 'ກຳລັງບັນທຶກ...' : 'ມອບໝາຍ'}
                </button>
              </div>
            </form>
          </div>
        )}

        {barcodeModalAsset && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-4 text-center">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-800">Barcode & QR</h2>
                <button type="button" onClick={() => setBarcodeModalAsset(null)} className="text-gray-400 hover:text-gray-600">
                  <X size={18} />
                </button>
              </div>

              <AssetTagVisual
                asset={barcodeModalAsset}
                claimBaseUrl={claimBaseUrl}
                showOriginWarning
                isLocalOrigin={isLocalOrigin}
                isIpOrigin={isIpOrigin}
              />

              {(() => {
                const a = barcodeModalAsset;
                const holder = a.currentAssigneeId ? users.find((u) => u._id === a.currentAssigneeId || u.employeeCode === a.currentAssigneeId) : null;
                if (!holder) return null;
                const deptHeld = isDeptHeld(a);
                const b = branches.find((br) => br._id === holder.branchId);
                const loc = b?.location;
                const locText = loc ? `${loc.address || ''}${loc.city ? `, ${loc.city}` : ''}${loc.country ? `, ${loc.country}` : ''}`.replace(/^, /, '') : '';
                return (
                  <div className="border-t border-gray-100 pt-3 text-left space-y-1">
                    <div className="text-xs font-semibold text-gray-600">{deptHeld ? 'ເປັນຂອງພະແນກ' : 'ຜູ້ຖືຢູ່ປັດຈຸບັນ'}</div>
                    {deptHeld && <div className="text-sm font-medium text-violet-700">{deptName(a.departmentId)}</div>}
                    <div className="text-sm font-medium text-gray-800">
                      {deptHeld ? 'ຜູ້ຮັບຜິດຊອບ: ' : ''}{`${holder.firstName || ''} ${holder.lastName || ''}`.trim() || holder.employeeCode}
                    </div>
                    <div className="text-xs text-gray-500">
                      {b ? (locText ? `${b.name} — ${locText}` : b.name) : holder.branchId || '—'}
                    </div>
                  </div>
                );
              })()}
              <div className="pt-2 space-y-2">
                <button 
                  type="button" 
                  onClick={() => { 
                    const id = barcodeModalAsset._id;
                    setBarcodeModalAsset(null); 
                    navigate(`/assets/${id}`); 
                  }} 
                  className="w-full px-4 py-2 text-sm bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-medium transition"
                >
                  ເປີດໜ້າລາຍລະອຽດ
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const id = barcodeModalAsset._id;
                    setBarcodeModalAsset(null);
                    navigate(`/assets/${id}?claim=1`);
                  }}
                  className="w-full px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition"
                >
                  ຮັບເຄື່ອງ / ຢືນຢັນ
                </button>
              </div>
            </div>
          </div>
        )}

        {historyModalAsset && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 w-full max-w-md space-y-3 max-h-[80vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-800">ປະຫວັດການມອບໝາຍ — {historyModalAsset.assetTag}</h2>
                <button type="button" onClick={() => setHistoryModalAsset(null)} className="text-gray-400 hover:text-gray-600">
                  <X size={20} />
                </button>
              </div>
              {(historyModalAsset.assignmentHistory || []).length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-6">ຍັງບໍ່ເຄີຍຖືກມອບໝາຍ</p>
              ) : (
                <div className="space-y-2">
                  {[...historyModalAsset.assignmentHistory].reverse().map((h, i) => (
                    <div key={h._id || i} className="border border-gray-100 rounded-xl p-3 text-sm">
                      <div className="font-medium text-gray-800">{userName(h.assigneeId)}</div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        {h.assignedAt ? new Date(h.assignedAt).toLocaleString() : '—'} —{' '}
                        {h.returnedAt ? new Date(h.returnedAt).toLocaleString() : <span className="text-blue-600 font-medium">ຍັງຖືຢູ່</span>}
                      </div>
                      {h.note && <div className="text-xs text-gray-500 mt-1 italic">"{h.note}"</div>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {bulkPrintOpen && (
          <AssetTagPrintModal assets={selectedAssets} claimBaseUrl={claimBaseUrl} onClose={() => setBulkPrintOpen(false)} />
        )}

        {bulkAssignOpen && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
            <form onSubmit={submitBulkAssign} className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-3">
              <h2 className="text-lg font-bold text-gray-800">ມອບໝາຍ {assignableSelected.length} ລາຍການ</h2>
              <p className="text-xs text-gray-500">ສະເພາະລາຍການທີ່ສະຖານະ "ວ່າງ" ເທົ່ານັ້ນ</p>
              <div className="space-y-2">
                <label className="block text-xs font-medium text-gray-700">ພະນັກງານ</label>
                <div className="relative">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    autoFocus
                    value={bulkUserSearch}
                    onChange={(e) => setBulkUserSearch(e.target.value)}
                    placeholder="ຄົ້ນຫາຊື່ ຫຼື ລະຫັດພະນັກງານ..."
                    className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-xl text-sm"
                  />
                </div>
                <select value={bulkUserDept} onChange={(e) => setBulkUserDept(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm">
                  <option value="">ທຸກພະແນກ</option>
                  {departments.filter((d) => d.isActive !== false).map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}
                </select>
                {(() => {
                  const q = bulkUserSearch.trim().toLowerCase();
                  const list = users.filter((u) => {
                    if (!u.isActive) return false;
                    if (bulkUserDept && userDeptId(u) !== bulkUserDept) return false;
                    if (!q) return true;
                    return `${u.firstName || ''} ${u.lastName || ''} ${u.employeeCode || ''}`.toLowerCase().includes(q);
                  });
                  return (
                    <div className="border border-gray-200 rounded-xl max-h-52 overflow-y-auto divide-y divide-gray-100">
                      {list.length === 0 && <div className="p-3 text-xs text-gray-400 text-center">ບໍ່ພົບພະນັກງານ</div>}
                      {list.map((u) => {
                        const on = bulkAssignUserId === u._id;
                        return (
                          <button
                            key={u._id}
                            type="button"
                            onClick={() => setBulkAssignUserId(u._id)}
                            className={`w-full text-left px-3 py-2 text-sm flex items-center justify-between gap-2 ${on ? 'bg-amber-50 text-amber-800' : 'hover:bg-gray-50 text-gray-700'}`}
                          >
                            <span>
                              <span className="font-medium">{u.firstName} {u.lastName}</span>
                              <span className="text-xs text-gray-400"> ({u.employeeCode})</span>
                              <span className="block text-[11px] text-gray-400">{deptName(u.departmentId)}</span>
                            </span>
                            {on && <CheckCircle2 size={16} className="text-amber-500 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">ໝາຍເຫດ (ບໍ່ບັງຄັບ)</label>
                <input type="text" value={bulkAssignNote} onChange={(e) => setBulkAssignNote(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm" />
              </div>
              {bulkAssignError && <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{bulkAssignError}</div>}
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setBulkAssignOpen(false)} className="px-4 py-2 text-sm text-gray-600">ຍົກເລີກ</button>
                <button type="submit" className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-medium">ມອບໝາຍ</button>
              </div>
            </form>
          </div>
        )}

        {bulkClaimOpen && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 w-full max-w-md space-y-4 max-h-[85vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-800">ຢືນຢັນການຮັບເຄື່ອງຫຼາຍລາຍການ</h2>
                <button type="button" onClick={closeBulkClaim} className="text-gray-400 hover:text-gray-600">
                  <X size={18} />
                </button>
              </div>

              {bulkClaimResults ? (
                <div className="space-y-3">
                  <div className="text-center space-y-2 py-1">
                    {bulkClaimResults.some((r) => r.ok)
                      ? <CheckCircle2 size={40} className="mx-auto text-emerald-500" />
                      : <XCircle size={40} className="mx-auto text-red-500" />}
                    <div className="font-semibold text-gray-800">
                      ສຳເລັດ {bulkClaimResults.filter((r) => r.ok).length}/{bulkClaimResults.length} ລາຍການ
                    </div>
                  </div>
                  {bulkClaimResults.some((r) => r.noRequest) && (
                    <div className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                      ພະນັກງານຄົນນີ້ບໍ່ມີໃບຂໍເບີກທີ່ອະນຸມັດແລ້ວ ແລະ ມີໂຄຕ້າເຫຼືອສຳລັບລາຍການນີ້ — ໃຫ້ຂໍ/ອະນຸມັດໃບຂໍກ່ອນ ແລ້ວຮັບເຄື່ອງຜ່ານໜ້າໃບຂໍ (ປຸ່ມ "ສະແກນເຄື່ອງ")
                    </div>
                  )}
                  <div className="space-y-1.5">
                    {bulkClaimResults.map((r, i) => (
                      <div
                        key={i}
                        className={`text-xs border rounded-lg px-3 py-2 flex items-center justify-between gap-2 ${
                          r.ok ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-red-50 border-red-200 text-red-600'
                        }`}
                      >
                        <span className="font-mono truncate">{r.assetTag}</span>
                        <span className="flex items-center gap-1 shrink-0">
                          {r.ok ? <CheckCircle2 size={13} /> : <XCircle size={13} />}
                          {r.ok ? 'ສຳເລັດ' : (r.message || 'ບໍ່ສຳເລັດ')}
                        </span>
                      </div>
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={closeBulkClaim}
                    className="w-full px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-medium transition"
                  >
                    ປິດ
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-xs text-gray-500">
                    {canAssign
                      ? `ຈະມອບໝາຍຊັບສິນ ${claimableCount} ລາຍການ ໃຫ້ຜູ້ທີ່ກຳລັງຈະມາຮັບ — ພິມລະຫັດພະນັກງານເພື່ອກວດຊື່ກ່ອນຢືນຢັນ:`
                      : `ຈະມອບໝາຍຊັບສິນ ${claimableCount} ລາຍການ ໃຫ້ບັນຊີທີ່ກຳລັງ login ເທົ່ານັ້ນ:`}
                  </p>
                  {canAssign && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">ລະຫັດພະນັກງານຜູ້ຮັບ *</label>
                      <input
                        type="text"
                        value={bulkClaimCode}
                        onChange={(e) => { setBulkClaimCode(e.target.value); setBulkClaimError(''); }}
                        placeholder="ຄົ້ນຫາຊື່ ຫຼື ລະຫັດພະນັກງານ ເຊັ່ນ USR200"
                        autoFocus
                        className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                      />
                      <select
                        value={bulkClaimDept}
                        onChange={(e) => setBulkClaimDept(e.target.value)}
                        className="w-full mt-2 border border-gray-300 rounded-xl px-3 py-2 text-sm"
                      >
                        <option value="">ທຸກພະແນກ</option>
                        {departments.filter((d) => d.isActive !== false).map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}
                      </select>
                      {(() => {
                        const q = bulkClaimCode.trim().toLowerCase();
                        const list = users.filter((u) => {
                          if (!u.isActive) return false;
                          if (bulkClaimDept && userDeptId(u) !== bulkClaimDept) return false;
                          if (!q) return true;
                          return `${u.firstName || ''} ${u.lastName || ''} ${u.employeeCode || ''}`.toLowerCase().includes(q);
                        });
                        return (
                          <div className="mt-2 border border-gray-200 rounded-xl max-h-44 overflow-y-auto divide-y divide-gray-100">
                            {list.length === 0 && <div className="p-3 text-xs text-gray-400 text-center">ບໍ່ພົບພະນັກງານ</div>}
                            {list.map((u) => {
                              const on = bulkCodeTrim.toLowerCase() === String(u.employeeCode || '').toLowerCase();
                              return (
                                <button
                                  key={u._id}
                                  type="button"
                                  onClick={() => { setBulkClaimCode(u.employeeCode || ''); setBulkClaimError(''); }}
                                  className={`w-full text-left px-3 py-2 text-sm flex items-center justify-between gap-2 ${on ? 'bg-amber-50 text-amber-800' : 'hover:bg-gray-50 text-gray-700'}`}
                                >
                                  <span>
                                    <span className="font-medium">{u.firstName} {u.lastName}</span>
                                    <span className="text-xs text-gray-400"> ({u.employeeCode})</span>
                                    <span className="block text-[11px] text-gray-400">{deptName(u.departmentId)}</span>
                                  </span>
                                  {on && <CheckCircle2 size={16} className="text-amber-500 shrink-0" />}
                                </button>
                              );
                            })}
                          </div>
                        );
                      })()}
                    </div>
                  )}
                  {canAssign && bulkCodeTrim && bulkLookup.state === 'found' && bulkLookup.user && (
                    <div className="bg-gray-50 rounded-xl p-3 text-sm space-y-1">
                      <div className="flex justify-between"><span className="text-gray-500">ຊື່-ນາມສະກຸນ</span><span className="font-medium text-gray-800">{`${bulkLookup.user.firstName || ''} ${bulkLookup.user.lastName || ''}`.trim() || '—'}</span></div>
                      <div className="flex justify-between"><span className="text-gray-500">ສາຂາ</span><span className="font-medium text-gray-800 text-right">{branchName(bulkLookup.user.branchId)}</span></div>
                      {bulkLookup.user.isActive === false && <div className="text-xs text-red-600">ບັນຊີນີ້ຖືກປິດໃຊ້ງານ</div>}
                    </div>
                  )}
                  {canAssign && bulkCodeTrim && bulkLookup.state === 'loading' && (
                    <div className="text-xs text-gray-500">ກຳລັງກວດລະຫັດ...</div>
                  )}
                  {canAssign && bulkCodeTrim && bulkLookup.state === 'notfound' && (
                    <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                      ບໍ່ພົບລະຫັດພະນັກງານນີ້ — ກວດກັບບັດພະນັກງານຂອງຜູ້ມາຮັບອີກຄັ້ງ
                    </div>
                  )}
                  {canAssign && bulkCodeTrim && bulkLookup.state === 'error' && (
                    <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                      ກວດລະຫັດບໍ່ໄດ້ຕອນນີ້ — Backend ຈະກວດຢືນຢັນອີກຄັ້ງຕອນບັນທຶກ
                    </div>
                  )}
                  <div className="bg-gray-50 rounded-xl p-4 text-sm space-y-2">
                    <div className="flex justify-between py-1 border-b border-gray-100">
                      <span className="text-gray-500">ຜູ້ຮັບ</span>
                      <span className="font-medium text-gray-800">
                        {canAssign
                          ? (bulkLookup.state === 'found' && bulkLookup.user
                            ? (`${bulkLookup.user.firstName || ''} ${bulkLookup.user.lastName || ''}`.trim() || bulkLookup.user.employeeCode || '—')
                            : '—')
                          : (claimUser ? (`${claimUser.firstName || ''} ${claimUser.lastName || ''}`.trim() || claimUser.email || '—') : '—')}
                      </span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-gray-100">
                      <span className="text-gray-500">ລະຫັດພະນັກງານ</span>
                      <span className="font-medium text-gray-800">{canAssign ? (bulkLookup.user?.employeeCode || bulkCodeTrim || '—') : (claimUser?.employeeCode || '—')}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-gray-500">ຈຳນວນຊັບສິນ</span>
                      <span className="font-medium text-gray-800">{claimableCount} ລາຍການ</span>
                    </div>
                  </div>
                  <div className="max-h-44 overflow-y-auto border border-gray-100 rounded-xl divide-y divide-gray-100">
                    {filteredAssets.filter((a) => selectedIds.has(a._id)).map((a) => (
                      <div key={a._id} className="px-3 py-2 text-xs flex items-center justify-between gap-2">
                        <span className="font-mono text-gray-800 truncate">{a.assetTag}</span>
                        <span className="text-gray-400 shrink-0">{a.type || '—'}</span>
                      </div>
                    ))}
                  </div>
                  {!claimUser && (
                    <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                      ບໍ່ສາມາດຢືນຢັນຕົວຕົນໄດ້ — ກະລຸນາ login ໃໝ່ແລ້ວລອງໃໝ່
                    </div>
                  )}
                  {bulkClaimError && (
                    <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{bulkClaimError}</div>
                  )}
                  <div className="flex justify-end gap-2">
                    <button type="button" onClick={closeBulkClaim} className="px-4 py-2 text-sm text-gray-600">ຍົກເລີກ</button>
                    <button
                      type="button"
                      onClick={confirmBulkClaim}
                      disabled={
                        bulkClaimSubmitting
                        || (canAssign
                          ? !bulkCodeTrim || bulkLookup.state !== 'found' || bulkLookup.user?.isActive === false
                          : !claimUser)
                      }
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-medium disabled:opacity-50"
                    >
                      {bulkClaimSubmitting ? 'ກຳລັງບັນທຶກ...' : 'ຢືນຢັນຮັບເຄື່ອງ'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {scannerOpen && (
          <CameraScanner
            title="ສະແກນ Asset Tag"
            hint="ຈ່ອງກ້ອງໃສ່ QR/ບາໂຄ໊ດ ເພື່ອຄົ້ນຫາຊັບສິນ"
            onScan={(text) => {
              const raw = String(text || '').trim();
              const urlMatch = raw.match(/\/assets\/([A-Za-z0-9_-]+)/);
              if (urlMatch) {
                setScannerOpen(false);
                setScanTargetId(urlMatch[1]);
                return;
              }
              setSearch(raw);
            }}
            onClose={() => setScannerOpen(false)}
          />
        )}

        {scanTargetId && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 w-full max-w-xs space-y-4 text-center">
              <div>
                <div className="text-sm font-semibold text-gray-800">ພົບ QR ຂອງຊັບສິນ</div>
                <div className="text-[11px] text-gray-500 mt-1">ເລືອກການກະທຳທີ່ຕ້ອງການ</div>
              </div>
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => { navigate(`/assets/${scanTargetId}?claim=1`); setScanTargetId(null); }}
                  className="w-full px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-medium transition"
                >
                  ຮັບເຄື່ອງ
                </button>
                <button
                  type="button"
                  onClick={() => { navigate(`/assets/${scanTargetId}`); setScanTargetId(null); }}
                  className="w-full px-4 py-2 border border-gray-300 text-gray-700 hover:bg-gray-50 rounded-xl text-sm font-medium transition"
                >
                  ເບິ່ງລາຍລະອຽດ
                </button>
                <button
                  type="button"
                  onClick={() => setScanTargetId(null)}
                  className="w-full px-4 py-2 text-gray-500 hover:text-gray-700 text-sm"
                >
                  ຍົກເລີກ
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}